﻿using System.Collections.Generic;
using System.Threading.Tasks;
using BookReading.Models;
using BookReading.Shared.DTOs;
using BookReading.Shared.ViewModels;
using Microsoft.AspNetCore.Identity;

namespace BookReading.BLL
{
    public interface IEventBLL
    {
        Task<bool> CreateEvent(EventViewModel eventViewModel);
        Task<List<EventDTO>> GetALLEvents();
        Task<EventDTO> GetEvent(int id);
        Task<EventViewModel> GetEventForEdit(int id);
        Task<bool> UpdateEvent(int id, EventViewModel eventViewModel);
        Task<IdentityResult> CreateUser(SignUpUserModel signupUserModel);
        Task<SignInResult> PasswordSignInAsync(SignInModel signInModel);
        Task SignOutAsync();
        Task<bool> UpdateComment(CommentsViewModel commentsViewModel);
        Task<List<CommentsViewDTO>> GetComments(int id);
    }
}
