﻿using System.Collections.Generic;
using System.Threading.Tasks;
using BookReading.Models;
using BookReading.Shared.DTOs;
using BookReading.Shared.ViewModels;
using Microsoft.AspNetCore.Identity;

namespace BookReading.DAL
{
    public interface IEventDAL
    {
        Task<int> CreateEvent(EventViewModel model);
        Task<IdentityResult> CreateUser(SignUpUserModel signupUserModel);
        Task<List<EventDTO>> GetALLEvents();
        Task<List<CommentsViewDTO>> GetComments(int id);
        Task<EventDTO> GetEvent(int id);
        Task<EventViewModel> GetEventForEdit(int id);
        Task<bool> UpdateComment(CommentsViewModel commentsViewModel);
        Task<bool> UpdateEvent(int id, EventViewModel eventViewModel);
        Task<SignInResult> PasswordSignInAsync(SignInModel signInModel);
        Task SignOutAsync();
    }
}