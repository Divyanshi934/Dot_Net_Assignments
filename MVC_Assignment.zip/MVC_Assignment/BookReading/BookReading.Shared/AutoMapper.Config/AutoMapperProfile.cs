﻿using AutoMapper;
using BookReading.Models;
using BookReading.Shared.DTOs;
using BookReading.Shared.Entities;
using BookReading.Shared.ViewModels;

namespace BookReading.Shared.AutoMapper.Config
{

    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<EventDTO, Events>()
                .ReverseMap();
            CreateMap<CommentsViewDTO, UserComment>()
                .ReverseMap();
            CreateMap<EventViewModel, Events>()
                .ReverseMap();
            CreateMap<ApplicationUser, SignUpUserModel>()
                .ReverseMap();
            CreateMap<CommentsViewModel, UserComment>()
                .ReverseMap();
            CreateMap<Events, EventViewModel>()
                .ReverseMap();
        }
    }
     
    
}