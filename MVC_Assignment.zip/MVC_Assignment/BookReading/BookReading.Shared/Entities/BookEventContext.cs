﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using BookReading.Shared.ViewModels;
namespace BookReading.Shared.Entities
{
    public class BookEventContext : IdentityDbContext<ApplicationUser>
    {
        public BookEventContext(DbContextOptions<BookEventContext> options)
            : base(options)
        {

        }
        
        public DbSet<Events> Events { get; set; }
        public DbSet<UserComment> UserComment { get; set; }
    }
}
