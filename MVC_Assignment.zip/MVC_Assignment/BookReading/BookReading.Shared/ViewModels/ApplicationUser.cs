﻿
using Microsoft.AspNetCore.Identity;

namespace BookReading.Shared.ViewModels
{
    public class ApplicationUser : IdentityUser
    {
        public string FullName { get; set; }
    }
}
