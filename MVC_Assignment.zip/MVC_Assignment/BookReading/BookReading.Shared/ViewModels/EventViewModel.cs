﻿using System;
using System.ComponentModel.DataAnnotations;


namespace BookReading.Models
{
    public class EventViewModel
    {

        [Key]
        public int Id { get; set; }
        public string Email { get; set; }
        [Required]
        public string Title { get; set; }
        [DataType(DataType.Date)]
        public DateTime? Date { get; set; }
        [Required]
        public string Location { get; set; }
        public DateTime? StartTime { get; set; }
        public string Type { get; set; }
        [Range(0,4)]
        public int? DurationInHours { get; set; }
        public string Description { get; set; }
        public string OtherDetails { get; set; }
        
        public string InviteByEmail { get; set; }

    }
}
