﻿using System;


namespace BookReading.Shared.ViewModels
{
    public class CommentsViewModel
    {

        public int EventId { get; set; }
        public string Comment { get; set; }
        public DateTime Date { get; set; }
    }
}
