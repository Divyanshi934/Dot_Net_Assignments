﻿using System.ComponentModel.DataAnnotations;

namespace BookReading.Shared.ViewModels
{
    public class SignUpUserModel
    {
        [Required(ErrorMessage = "Please enter your Full Name")]
        public string FullName { get; set; }
        [Required(ErrorMessage ="Please enter Email")]
        [Display(Name = "Email Address")]
        [EmailAddress(ErrorMessage ="Please enter a valid Email")]
        public string Email { get; set; }
        [Required(ErrorMessage ="Please enter Password")]
        [Compare("ConfirmPassword", ErrorMessage ="Password does not match")]
        [Display(Name = "Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Required(ErrorMessage = "Please confirm your Password")]
        [Display(Name = "Confirm Password")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }
    }
}
