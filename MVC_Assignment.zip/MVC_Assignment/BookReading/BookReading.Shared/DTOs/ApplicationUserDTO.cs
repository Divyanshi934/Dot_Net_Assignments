﻿

namespace BookReading.Shared.DTOs
{
    public class ApplicationUserDTO
    {
        public string FullName { get; set; }
    }
}
