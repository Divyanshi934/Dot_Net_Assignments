﻿using System;


namespace BookReading.Shared.DTOs
{
    public class EventDTO
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Title { get; set; }
        public DateTime? Date { get; set; }
        public string Location { get; set; }
        public DateTime? StartTime { get; set; }
        public string Type { get; set; }
        public int? DurationInHours { get; set; }
        public string Description { get; set; }
        public string OtherDetails { get; set; }
        public string InviteByEmail { get; set; }
    }
}
