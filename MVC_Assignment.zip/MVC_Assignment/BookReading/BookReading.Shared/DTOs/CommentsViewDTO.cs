﻿using System;


namespace BookReading.Shared.DTOs
{
    public class CommentsViewDTO
    {
        public int EventId { get; set; }
        public string Comment { get; set; }
        public DateTime Date { get; set; }
    }
}
