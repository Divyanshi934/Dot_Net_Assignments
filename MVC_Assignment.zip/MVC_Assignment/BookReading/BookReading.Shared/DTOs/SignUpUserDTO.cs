﻿
namespace BookReading.Shared.DTOs
{
    public class SignUpUserDTO
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
    }
}
