﻿

namespace BookReading.Shared.DTOs
{
    public class SignInDTO
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
