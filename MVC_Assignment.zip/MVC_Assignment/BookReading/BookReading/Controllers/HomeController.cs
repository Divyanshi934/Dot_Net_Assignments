﻿using System.Threading.Tasks;
using BookReading.BLL;
using Microsoft.AspNetCore.Mvc;

namespace BookReading.Controllers
{
    public class HomeController : Controller
    {
        //for creating object for business logic layer
        private readonly IEventBLL _eventBLL = null;
        public HomeController(IEventBLL eventBLL)
        {
            _eventBLL = eventBLL;
        }

        //home page and display public events
        public async Task<ViewResult> Index()
        {
            var events = await _eventBLL.GetALLEvents();
            return View(events);
        }

    }
}
