﻿using System.Threading.Tasks;
using BookReading.BLL;
using BookReading.Shared.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BookReading.Controllers
{
    public class AccountController : Controller
    {
        //for creating object of business logic layer
        private readonly IEventBLL _eventBLL = null;
        public AccountController(IEventBLL eventBLL)
        {
            _eventBLL = eventBLL;
        }

        //method for opening signup form
        [Route("signup")]
        public ViewResult Signup()
        {
            return View();
        }

        //method after submit signup form
        [Route("signup")]
        [HttpPost]
        public async Task<IActionResult> Signup(SignUpUserModel signUpUserModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _eventBLL.CreateUser(signUpUserModel);
                if (!result.Succeeded)
                {
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                    return View();
                }
                return RedirectToAction("Login","Account");
            }
            return View();
        }

        //method for opening login form
        [Route("login")]
        public ViewResult Login()
        {
            return View();
        }

        //method after submit login form
        [Route("login")]
        [HttpPost]
        public async Task<IActionResult> Login(SignInModel signInModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _eventBLL.PasswordSignInAsync(signInModel);
                if (result.Succeeded)
                {
                    return RedirectToAction("Index", "Home");
                }
                ModelState.AddModelError("", "Invalid credentials");
            }
            return View();
        }

        //method for logout the user
        [Authorize]
        [Route("logout")]
        public async Task<IActionResult> Logout()
        {
            await _eventBLL.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }
    }
}
