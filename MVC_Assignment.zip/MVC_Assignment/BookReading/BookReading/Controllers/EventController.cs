﻿using System;
using System.Threading.Tasks;
using BookReading.BLL;
using BookReading.Models;
using BookReading.Shared.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BookReading.Controllers
{
    public class EventController : Controller
    {
        //for creating object for business logic layer
        private readonly IEventBLL _eventBLL = null;
        public EventController(IEventBLL eventBLL)
        {
            _eventBLL = eventBLL;
        }

        //method for open form for creating event
        [Authorize]
        public ViewResult CreateEvent(bool eventCreated)
        {
            ViewBag.EventCreated = eventCreated;
            return View();
        }

        //method after submit the create event form
        [HttpPost]
        public async Task<IActionResult> CreateEvent(EventViewModel eventViewModel)
        {
            if (ModelState.IsValid)
            {
                if (await _eventBLL.CreateEvent(eventViewModel))
                {
                    return RedirectToAction("CreateEvent", new { eventCreated = true });
                }
            }
            return View();
        }

        //method for display invited events to the user
        [Authorize]
        public async Task<ViewResult> InvitedEvents()
        {
            var events = await _eventBLL.GetALLEvents();
            return View(events);
        }

        //method for getting all types of events
        [Authorize(Policy = "Admin")]
        public async Task<ViewResult> GetALLEvent()
        {
            var events = await _eventBLL.GetALLEvents();
            return View(events);
        }

        //method for getting info of event

        public async Task<ViewResult> GetEvent(int id)
        {
            ViewBag.eve = await _eventBLL.GetComments(id);
            ViewBag.events = await _eventBLL.GetEvent(id);
            return View();
        }

        //method after comments by anyone
        [HttpPost]
        public async Task<IActionResult> GetEvent(CommentsViewModel commentsViewModel)
        {
            commentsViewModel.Date = DateTime.Now;
            await _eventBLL.UpdateComment(commentsViewModel);
            return RedirectToAction("GetEvent");
        }

        //method for editevent form opening
        [Authorize]
        public async Task<ViewResult> EditEvent(int id)
        {
            var events = await _eventBLL.GetEventForEdit(id);
            return View(events);
        }

        //method after submit the edit event
        [HttpPost]
        public async Task<IActionResult> EditEvent(EventViewModel eventViewModel)
        {
            if (ModelState.IsValid)
            {
                if (await _eventBLL.UpdateEvent(eventViewModel.Id, eventViewModel))
                {
                    return RedirectToAction("GetALLEvent");
                }
            }
            return View();
        }
        //method for getting event created by particular user
        [Authorize]
        public async Task<ViewResult> MyEvents()
        {
            var events = await _eventBLL.GetALLEvents();
            return View(events);
        }
    }
}
