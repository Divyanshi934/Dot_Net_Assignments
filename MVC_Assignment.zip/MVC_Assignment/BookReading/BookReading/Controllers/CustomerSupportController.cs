﻿using Microsoft.AspNetCore.Mvc;

namespace BookReading.Controllers
{
    public class CustomerSupportController : Controller
    {
        //method for customer support
        
        [Route("customer-support")]
        public IActionResult Support()
        {
            return Redirect("https://helpdesk.nagarro.com");
        }
    }
}
