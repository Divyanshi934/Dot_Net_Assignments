﻿
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace BookReading
{
    public class AdminIdHandler : AuthorizationHandler<MailIdShouldBe>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context,
                                                       MailIdShouldBe requirement)
        {
            if (requirement.MailId==context.User.Identity.Name)
            {
                context.Succeed(requirement);
            }
            return Task.CompletedTask;
        }
    }
}