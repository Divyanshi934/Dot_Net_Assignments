﻿
using Microsoft.AspNetCore.Authorization;

namespace BookReading
{
    public class MailIdShouldBe : IAuthorizationRequirement
    {
        public string MailId { get; }

        public MailIdShouldBe(string mailId)
        {
            MailId = mailId;
        }
    }
}