using BookReading.BLL;
using BookReading.DAL;
using BookReading.Shared.AutoMapper.Config;
using BookReading.Shared.Entities;
using BookReading.Shared.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;

namespace BookReading
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IConfiguration Configuration { get; }
        
        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
          
            services.AddDbContext<BookEventContext>(
                options => options.UseSqlServer(Configuration.GetConnectionString("DatabaseConnection")));

            //add identity framework services
            services.AddIdentity<ApplicationUser, IdentityRole>()
                .AddEntityFrameworkStores<BookEventContext>();

            //add password requirement service
            services.Configure<IdentityOptions>(options =>
            {
                options.Password.RequiredLength = 5;
                options.Password.RequiredUniqueChars = 1;
            });
            
            //add service for controller and views in web app
            services.AddControllersWithViews();

            //add service for getting login user context
            services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            //add service for policy based authorization
            services.AddAuthorization(options =>
            {
                options.AddPolicy("Admin", policy =>
                    policy.Requirements.Add(new MailIdShouldBe("myadmin@bookevents.com")));
            });
            //add authorization handler by dependency injection
            services.AddSingleton<IAuthorizationHandler, AdminIdHandler>();

            //add run time compilation service
            services.AddRazorPages().AddRazorRuntimeCompilation();

            //add event data access layer by dependency injection
            services.AddScoped<IEventDAL, EventDAL>();

            //add event business logic layer by dependency injection
            services.AddScoped<IEventBLL, EventBLL>();

            //add automapper
            var config = new AutoMapper.MapperConfiguration(c =>
            {
                c.AddProfile(new AutoMapperProfile());
            });
            var mapper = config.CreateMapper();
            services.AddSingleton(mapper);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            //check eveironment 
            if(env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseHttpsRedirection();

            //routing for use static files
            app.UseStaticFiles();

            //for added routing for going to particular url on starting app
            app.UseRouting();

            //routing for authentication before calling method
            app.UseAuthentication();
            app.UseAuthorization();

            //default routing 
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
