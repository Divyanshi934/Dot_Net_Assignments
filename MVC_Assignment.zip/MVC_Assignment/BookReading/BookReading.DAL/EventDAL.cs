﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using BookReading.Models;
using BookReading.Shared.DTOs;
using BookReading.Shared.Entities;
using BookReading.Shared.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace BookReading.DAL
{
    public class EventDAL : IEventDAL, IAuthorizationRequirement
    {
        private readonly BookEventContext _bookEventContext = null;
        private readonly UserManager<ApplicationUser> _userManager = null;
        private readonly SignInManager<ApplicationUser> _signInManager = null;
        private readonly IMapper _mapper;
       
        public EventDAL(BookEventContext bookEventContext, UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager, IMapper mapper)
        {
            _bookEventContext = bookEventContext;
            _userManager = userManager;
            _signInManager = signInManager;
            _mapper = mapper;
        }
       
        //method for creating event and store details in database
        //and return event ID
        public async Task<int> CreateEvent(EventViewModel model)
        {

            Events newEvent = _mapper.Map<Events>(model);
            await _bookEventContext.Events.AddAsync(newEvent);
            await _bookEventContext.SaveChangesAsync();
            return newEvent.Id;
        }

        //method for logout user
        public async Task SignOutAsync()
        {
            await _signInManager.SignOutAsync();
        }

        //method for check login id and password is correct or not
        public async Task<SignInResult> PasswordSignInAsync(SignInModel signInModel)
        {
            return await _signInManager.PasswordSignInAsync(signInModel.Email, signInModel.Password, false, false);
        }

        //method for signup user and store data in database
        //and return result
        public async Task<IdentityResult> CreateUser(SignUpUserModel signupUserModel)
        {
            var user = new ApplicationUser()
            {
                Email=signupUserModel.Email,
                UserName=signupUserModel.Email,
                FullName=signupUserModel.FullName
            };
            var result = await _userManager.CreateAsync(user, signupUserModel.Password);
            return result;
        }

        //method for taking comments from database and return to event details page
        public async Task<List<CommentsViewDTO>> GetComments(int id)
        {
            var storeEvents = new List<CommentsViewDTO>();
            var events = await _bookEventContext.UserComment.Where(x => x.EventId == id).ToListAsync();
            if (events?.Any() == true)
            {
                foreach (var eve in events)
                {
                    storeEvents.Add(_mapper.Map<CommentsViewDTO>(eve));
                }
            }
            return storeEvents;
        }

        //comment update to database
        public async Task<bool> UpdateComment(CommentsViewModel commentsViewModel)
        {

            var newEvent = _mapper.Map<UserComment>(commentsViewModel);
            await _bookEventContext.UserComment.AddAsync(newEvent);
            await _bookEventContext.SaveChangesAsync();
            return true;
        }

        //edit event 
        public async Task<bool> UpdateEvent(int id, EventViewModel eventViewModel)
        {
            var eve = await _bookEventContext.Events.FindAsync(id);
            if (eve != null)
            {
                _mapper.Map<Events>(eventViewModel);
            }
            await _bookEventContext.SaveChangesAsync();
            return true;
        }

        //get event using event id
        public async Task<EventDTO> GetEvent(int id)
        {
            var eve = await _bookEventContext.Events.FindAsync(id);
            if (eve != null)
            {
                EventDTO newEvent = _mapper.Map<EventDTO>(eve);
                return newEvent;
            }
            return null;
        }
        //get event using event id for editing
        public async Task<EventViewModel> GetEventForEdit(int id)
        {
            var eve = await _bookEventContext.Events.FindAsync(id);
            if (eve != null)
            {
                var newEvent = _mapper.Map<EventViewModel>(eve);
                return newEvent;
            }
            return null;
        }

        //return all events stored in database
        public async Task<List<EventDTO>> GetALLEvents()
        {
            var storeEvents = new List<EventDTO>();
            var events = await _bookEventContext.Events.ToListAsync();
            if (events?.Any() == true)
            {
                foreach (var eve in events)
                {
                    storeEvents.Add(_mapper.Map<EventDTO>(eve));
                }
            }
            return storeEvents;

        }
    }
}


/*using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using BookReading.Models;
using BookReading.Shared.DTOs;
using BookReading.Shared.Entities;
using BookReading.Shared.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace BookReading.DAL
{
    public class : IEventDAL, IAuthorizationRequirement
    {
        //private readonly IUnitOfWork _unitOfWork = null;
        private readonly BookEventContext _bookEventContext = null;
    private readonly UserManager<ApplicationUser> _userManager = null;
    private readonly SignInManager<ApplicationUser> _signInManager = null;
    private readonly IMapper _mapper;

    public EventDAL(BookEventContext bookEventContext, UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager, IMapper mapper)
    {
        _bookEventContext = bookEventContext;
        _userManager = userManager;
        _signInManager = signInManager;
        _mapper = mapper;
    }

    //method for creating event and store details in database
    //and return event ID
    public async Task<int> CreateEvent(EventViewModel model)
    {

        Events newEvent = _mapper.Map<Events>(model);
        await _bookEventContext.Events.AddAsync(newEvent);
        await _bookEventContext.SaveChangesAsync();
        return newEvent.Id;
    }

    public async Task SignOutAsync()
    {
        await _signInManager.SignOutAsync();
    }

    //method for check login id and password is correct or not
    public async Task<SignInResult> PasswordSignInAsync(SignInModel signInModel)
    {
        return await _signInManager.PasswordSignInAsync(signInModel.Email, signInModel.Password, false, false);
    }

    //method for signup user and store data in database
    //and return result
    public async Task<IdentityResult> CreateUser(SignUpUserModel signupUserModel)
    {
        var user = new ApplicationUser()
        {
            Email = signupUserModel.Email,
            UserName = signupUserModel.Email,
            FullName = signupUserModel.FullName
        };
        var result = await _userManager.CreateAsync(user, signupUserModel.Password);
        return result;
    }

    //method for taking comments from database and return to event details page
    public async Task<List<CommentsViewDTO>> GetComments(int id)
    {
        var storeEvents = new List<CommentsViewDTO>();
        var events = await _bookEventContext.UserComment.Where(x => x.EventId == id).ToListAsync();
        if (events?.Any() == true)
        {
            foreach (var eve in events)
            {
                storeEvents.Add(_mapper.Map<CommentsViewDTO>(eve));
            }
        }
        return storeEvents;
    }



    //comment update to database
    public async Task<bool> UpdateComment(CommentsViewModel commentsViewModel)
    {

        var newEvent = _mapper.Map<UserComment>(commentsViewModel);
        await _bookEventContext.UserComment.AddAsync(newEvent);
        await _bookEventContext.SaveChangesAsync();
        return true;
    }

    //edit event 
    public async Task<bool> UpdateEvent(int id, EventViewModel eventViewModel)
    {
        var eve = await _bookEventContext.Events.FindAsync(id);
        if (eve != null)
        {
            _mapper.Map<Events>(eventViewModel);
        }
        await _bookEventContext.SaveChangesAsync();
        return true;
    }

    //get event using event id
    public async Task<EventDTO> GetEvent(int id)
    {
        var eve = await _bookEventContext.Events.FindAsync(id);
        if (eve != null)
        {
            EventDTO newEvent = _mapper.Map<EventDTO>(eve);
            return newEvent;
        }
        return null;
    }

    //get event using event id for editing
    public async Task<EventViewModel> GetEventForEdit(int id)
    {
        return await _unitOfWork.Events.GetEventForEdit(id);
    }

    //return all events stored in database
    public async Task<List<EventDTO>> GetALLEvents()
    {

        return await _unitOfWork.Events.GetALLEvents();

    }

    public async Task<IdentityResult> CreateUser(SignUpUserModel signupUserModel)
    {
        var user = new ApplicationUser()
        {
            Email = signupUserModel.Email,
            UserName = signupUserModel.Email,
            FullName = signupUserModel.FullName
        };
        var result = await _userManager.CreateAsync(user, signupUserModel.Password);
        return result;
    }

    public async Task SignOutAsync()
    {
        await _signInManager.SignOutAsync();
    }

    //method for check login id and password is correct or not
    public async Task<SignInResult> PasswordSignInAsync(SignInModel signInModel)
    {
        return await _signInManager.PasswordSignInAsync(signInModel.Email, signInModel.Password, false, false);
    }

    public async Task<bool> UpdateEvent(int id, EventViewModel eventViewModel)
    {
        await _unitOfWork.Events.EditEvent(id, eventViewModel);
        await _unitOfWork.Commit();
        return true;
    }
}
}


    /*

    //method for logout user
    public async Task SignOutAsync()
    {
        await _signInManager.SignOutAsync();
    }

    //method for check login id and password is correct or not
    public async Task<SignInResult> PasswordSignInAsync(SignInModel signInModel)
    {
        return await _signInManager.PasswordSignInAsync(signInModel.Email, signInModel.Password, false, false);
    }

    //method for signup user and store data in database
    //and return result
    public async Task<IdentityResult> CreateUser(SignUpUserModel signupUserModel)
    {
        var user = new ApplicationUser()
        {
            Email=signupUserModel.Email,
            UserName=signupUserModel.Email,
            FullName=signupUserModel.FullName
        };
        var result = await _userManager.CreateAsync(user, signupUserModel.Password);
        return result;
    }
    /*
    //method for taking comments from database and return to event details page
    public async Task<List<CommentsViewDTO>> GetComments(int id)
    {
        var storeEvents = new List<CommentsViewDTO>();
        var events = await _bookEventContext.UserComments.Where(x => x.EventId == id).ToListAsync();
        if (events?.Any() == true)
        {
            foreach (var eve in events)
            {
                storeEvents.Add(_mapper.Map<CommentsViewDTO>(eve));
            }
        }
        return storeEvents;
    }

    //comment update to database
    public async Task<bool> UpdateComment(CommentsViewModel commentsViewModel)
    {

        var newEvent = _mapper.Map<UserComment>(commentsViewModel);
        await _bookEventContext.UserComments.AddAsync(newEvent);
        await _bookEventContext.SaveChangesAsync();
        return true;
    }

    //edit event 
    public async Task<bool> UpdateEvent(int id, EventViewModel eventViewModel)
    {
        var eve = await _bookEventContext.Events.FindAsync(id);
        if (eve != null)
        {
            _mapper.Map<Event>(eventViewModel);
        }
        await _bookEventContext.SaveChangesAsync();
        return true;
    }

    //get event using event id
    public async Task<EventDTO> GetEvent(int id)
    {
        var eve = await _bookEventContext.Events.FindAsync(id);
        if (eve != null)
        {
            EventDTO newEvent = _mapper.Map<EventDTO>(eve);
            return newEvent;
        }
        return null;
    }
    //get event using event id for editing
    public async Task<EventViewModel> GetEventForEdit(int id)
    {
        var eve = await _bookEventContext.Events.FindAsync(id);
        if (eve != null)
        {
            var newEvent = _mapper.Map<EventViewModel>(eve);
            return newEvent;
        }
        return null;
    }
    */
    //return all events stored in database*/
    