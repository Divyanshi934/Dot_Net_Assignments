using BookReading.BLL;
using BookReading.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;

using Xunit;

namespace UnitTesting
{
    public class AccountControllerTests
    {
        private readonly Mock<IEventBLL> service;
       
        public AccountControllerTests()
        {
            service = new Mock<IEventBLL>();
        }
        [Fact]
        public void Signup()
        {
            //arrange
            var controller = new AccountController(service.Object);
            //act
            var result = controller.Signup() as ViewResult;
            //assert
            Assert.NotNull(result);
        }
        [Fact]
        public void Login()
        {
            //arrange
            var controller = new AccountController(service.Object);
            //act
            var result = controller.Login() as ViewResult;
            //assert
            Assert.NotNull(result);
        }
    }
}
