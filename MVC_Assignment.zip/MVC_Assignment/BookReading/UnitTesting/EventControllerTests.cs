﻿using System.Threading.Tasks;
using BookReading.BLL;
using BookReading.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace UnitTesting
{
    public class EventControllerTests
    {
        private readonly Mock<IEventBLL> service;
        public EventControllerTests()
        {
            service = new Mock<IEventBLL>();
        }
        [Fact]
        public void EditEvent()
        {
            //arrange
            var id = 7;
            var controller = new EventController(service.Object);
            //act
            var result = controller.EditEvent(id) as Task<ViewResult>;
            //assert
            Assert.NotNull(result);
        }
        [Fact]
        public void MyEvents()
        {
            //arrange
            var controller = new EventController(service.Object);
            //act
            var result = controller.MyEvents() as Task<ViewResult>;
            //assert
            Assert.NotNull(result);
        }
        [Fact]
        public void CreateEvent()
        {
            //arrange
            var controller = new EventController(service.Object);
            //act
            ViewResult result = controller.CreateEvent(false) as ViewResult;
            //assert
            Assert.NotNull(result);
            Assert.Equal(false, result.ViewData["EventCreated"]);
        }

    }
}
