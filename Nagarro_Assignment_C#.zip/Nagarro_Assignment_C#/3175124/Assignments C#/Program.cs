﻿//using System.IO;
using System;

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            //BASIC C# PROGRAM ASSIGNMENTS

            //Converting To Integer values
            int ans1, ans2, ans3;
            string myStr;
            Console.WriteLine("Enter a value: ");
            myStr = Console.ReadLine();
            ans1 = int.Parse(myStr);
            ans2 = Convert.ToInt32(myStr);
            int.TryParse(myStr,out ans3);
            Console.WriteLine("Integer value is converted using int.parse: " + ans1);
            Console.WriteLine("Integer value is converted using Convert.ToInt: " + ans2);
            Console.WriteLine("Integer value is converted using int.TryParse: " + ans3);
            double myDouble = 9.78;
            int myInt = (int)myDouble;
            Console.WriteLine("Integer value is converted from double to int "+myInt);



            //Converting To Float Values
            double a;
            Console.WriteLine("Enter values to convert it into Float: ");
            myStr = Console.ReadLine();
            a = Convert.ToDouble(myStr);
            Console.WriteLine("Float value is converted from string to double: " + a);
            string str1;
            string str2;
            str1 = Console.ReadLine();
            str2 = Console.ReadLine();
            float f1 = float.Parse(str1);
            float f2 = float.Parse(str2);
            Console.WriteLine(f1 + f2);



            //Converting To Boolean
            string sample;
            Console.WriteLine("Enter True/False: ");
            sample = Console.ReadLine();
            bool myBool = bool.Parse(sample);

            Convert.ToBoolean(sample);

            //difference between “==” operator, object.Equals methods and object.ReferenceEquals method.
            object name1 = "divyanshi";
            string name = "divyanshi";
            char[] values = { 'd', 'i', 'v', 'y', 'a', 'n', 's', 'h', 'i' };
            string myName = name;
            object myname1 = new string(values);
            Console.WriteLine("== operator result gives {0} ", name == myName);
            Console.WriteLine("== operator result is {0}", myname1 == values);
            Console.WriteLine("Equals method result is {0}", name.Equals(myName));
            Console.ReadKey();
        }
    }
}
