﻿using System;


namespace Nagarro_Assignment
{
    class Program
    {
        private static void SendNotification(object sender, TransactionEventArgs e)
        {
            if (e.TranactionType == "Added")
            {
                Console.WriteLine("New {0} Product is: Id: {1}, Price: {2}, Qty: {3}, IsDefective: {4}, TotalValue: {5}", e.TranactionType, e.Products.Id,
                    e.Products.Price, e.Products.Qty, e.Products.IsDefective, e.Products.TotalValue);
            }
            else
            {
                Console.WriteLine("{0} Product is: Id: {1}, Price: {2}, Qty: {3}, IsDefective: {4}, TotalValue: {5}", e.TranactionType, e.Products.Id,
                    e.Products.Price, e.Products.Qty, e.Products.IsDefective, e.Products.TotalValue);
            }
        }
        static void Main(string[] args)
        {
            Product obj = new Product();
            obj.TransactionMade += new TransactionHandler(SendNotification);
            obj.AddProduct(1, 10, 3, false);
            obj.AddProduct(2, 5, 4, false);
            obj.AddProduct(3, 6, 5, false);
            obj.AddProduct(4, 2, 4, false);
            obj.AddProduct(5, 3, 5, false);
            obj.AddProduct(6, 4, 5, true);
            obj.RemoveProduct(3);
            obj.UpdateQty(2, 10);
            obj.UpdatePrice(4, 5);
            obj.UpdateIsDefective(5, true);
            obj.UpdateIsDefective(6, false);
            Console.ReadLine();
        }
    }
}
