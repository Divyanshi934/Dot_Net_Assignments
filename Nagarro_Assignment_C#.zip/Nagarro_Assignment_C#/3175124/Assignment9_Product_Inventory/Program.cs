﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Nagarro_Assignment
{

    public delegate void TransactionHandler(object sender, TransactionEventArgs e);
    public class Product
    {
        public int Id { get; set; }
        public decimal Price { get; set; }
        public int Qty { get; set; }
        public bool IsDefective { get; set; }
        public decimal TotalValue { get; set; }

        public Product() { }
        public Product(int id, decimal price, int qty, bool isdefective)
        {
            this.Id = id;
            this.Price = price;
            this.Qty = qty;
            this.IsDefective = isdefective;
            this.TotalValue = price * qty;
        }

        List<Product> Inventory = new List<Product>();

        public event TransactionHandler TransactionMade;
        public void AddProduct(int id, decimal price, int qty, bool isdefective)
        {
            Inventory.Add(new Product(id, price, qty, isdefective));
            TransactionEventArgs e = new TransactionEventArgs(new Product(id, price, qty, isdefective), "Added");
            OnTransactionMade(e);
        }
        public void RemoveProduct(int id)
        {
            Product removeItm = Inventory.Where(x => x.Id == id).First();
            Inventory.RemoveAll(x => x.Id == id);
            TransactionEventArgs e = new TransactionEventArgs(removeItm, "\nRemoved");
            OnTransactionMade(e);
        }
        public void UpdateQty(int id, int qty)
        {
            foreach (var inv in Inventory.Where(x => x.Id == id))
            {
                inv.Qty = qty;
                inv.TotalValue = inv.Price * qty;
            }
            Product updateqItm = Inventory.Where(x => x.Id == id).First();
            TransactionEventArgs e = new TransactionEventArgs(updateqItm, "\nUpdatedQantity");
            OnTransactionMade(e);
        }
        public void UpdatePrice(int id, decimal amt)
        {
            foreach (var inv in Inventory.Where(x => x.Id == id))
            {
                inv.Price = amt;
                inv.TotalValue = inv.Qty * amt;
            }
            Product updatepItm = Inventory.Where(x => x.Id == id).First();

            TransactionEventArgs e = new TransactionEventArgs(updatepItm, "\nUpdatedPrice");
            OnTransactionMade(e);
        }
        public void UpdateIsDefective(int id, bool flag)
        {
            Product updatedefItm;
            if (flag == true)
            {
                updatedefItm = Inventory.Where(x => x.Id == id).First();
                Inventory.RemoveAll(x => x.Id == id);
                TransactionEventArgs e = new TransactionEventArgs(updatedefItm, "\nRemoved");
                OnTransactionMade(e);
            }
            else
            {
                foreach (var inv in Inventory.Where(x => x.Id == id))
                    inv.IsDefective = flag;
                updatedefItm = Inventory.Where(x => x.Id == id).First();
                TransactionEventArgs e = new TransactionEventArgs(updatedefItm, "\nUpdatedIsDefective");
                OnTransactionMade(e);
            }

        }

        protected virtual void OnTransactionMade(TransactionEventArgs e)
        {
            if (TransactionMade != null)
            {
                TransactionMade(this, e);
            }
        }

    }
    public class TransactionEventArgs : EventArgs
    {
        private Product Item;
        private string TransactionType;
        public TransactionEventArgs(Product itm, string type)
        {
            this.Item = itm;
            this.TransactionType = type;
        }
        public Product Products
        {
            get
            {
                return Item;
            }
        }

        public string TranactionType
        {
            get
            {
                return TransactionType;
            }
        }
    }

}

