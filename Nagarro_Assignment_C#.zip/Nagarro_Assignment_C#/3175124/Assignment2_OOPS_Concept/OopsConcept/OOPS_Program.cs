﻿using System;

namespace OopsConcept
{
    class program
    {
        enum EquipmentType { Mobile = 0, ImMobile = 1 };

        public interface Details
        {
            void ShowDetails();
        }
        class Eqp : Details
        {
           // private string name;
           // private string des;
            private int distance=0;
            private int maintanenceCost=0;
            private EquipmentType EqpType;

            public Eqp()
            {

            }
            public Eqp( int distance, int maintanenceCost, EquipmentType EqpType)
            {
               // this.name = name;
                //this.des = des;
                this.distance = distance;
                this.maintanenceCost = maintanenceCost;
                this.EqpType = EqpType;
            }


            public virtual void ShowDetails()
            {
                int wheel = 4;
                int weight = 10;
                
                if (EqpType == EquipmentType.Mobile)
                {
                    Console.WriteLine("Jeep");
                    Console.WriteLine("Description: a Mobile equipment");
                    Console.WriteLine("wheels are: " + wheel);

                    int maintainCost = distance * wheel;
                    //  maintainC = Convert.ToInt32(maintainCost);
                    Console.WriteLine("Total maintanence Cost is: " + maintainCost+ " Rs");
                }
                
                if (EqpType == EquipmentType.ImMobile)
                {
                    Console.WriteLine("Trolley");
                    Console.WriteLine("Description: Immobile Equipment ");
                    Console.WriteLine("weight is: " + weight+ " kg");
                    int maintainCost = distance * weight;
                    //  maintainC = Convert.ToInt32(maintainCost);
                    Console.WriteLine("Total maintanence Cost is: " + maintainCost+ " Rs");
                }
               
                Console.WriteLine("Distance till date {0} km", distance);
                //Console.WriteLine("Maintainence Cost {0} ", );

            }
        }
        class Mobile : Eqp
        {
            public Mobile(int distance,int maintanenceCost, EquipmentType EqpType) : base( distance,maintanenceCost,  EqpType)
            {

            }
            public override void ShowDetails()
            {
                base.ShowDetails();
                //Console.WriteLine("Tractor is a mobile equipment");
            }
        }

        class ImMobile : Eqp
        {
            public ImMobile(int distance, int maintainenceCost ,EquipmentType EqpType) : base(distance, maintainenceCost, EqpType)
            {

            }
            public override void ShowDetails()
            {
                base.ShowDetails();
                //Console.WriteLine("Tractor is a mobile equipment");
            }
        }
        static void Main(string[] args)
        {
            Details[] Equipment = new Details[2];
            Equipment[0] = new Mobile(20,0, EquipmentType.Mobile);
            Equipment[1] = new ImMobile(30,0, EquipmentType.ImMobile);
           

            for (int i = 0; i <= 1; i++)
            {
                Equipment[i].ShowDetails();
                Console.WriteLine();
            }
            Console.ReadLine();

        }
    }
}  























   

