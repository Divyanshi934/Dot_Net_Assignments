﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Extensionmethods
{
    public static class IntExtensions
    {
        public static bool IsEven(this int i)
        {
            return ((i % 2) == 0);
        }

        public static bool IsPrimeNumber(this int i)
        {
            if (i == 1) 
                return false;
            if (i == 2) 
                return true;

            double boundry = Math.Floor(Math.Sqrt(i));

            for (int j = 2; j <= boundry; ++j)
            {
                if ((i % j) == 0) 
                    return false;
            }

            return true;
        }

        public static bool IsDivisibleBy(this int i)
        {
            return (i % 5 == 0);
               
        }

    }
}




/*namespace Extension_Metoods
{
    public static class SimpleExtensionMethods
    {
        int[] numbers = new int[]
{
    1, 3, 5, 6, 8, 9, 10
};
 
// out each result
foreach(int i in numbers)
{
    Console.Write("Testing #" + i.ToString() + ":\t");
 
    if(i.IsEven())
    {
        Console.Write("Even");
    }
    else
    {
        Console.Write("Odd");
    }

if (i.IsPrimeNumber())
{
    Console.Write(", Prime Number");
}

Console.WriteLine();
}
}
}*/
