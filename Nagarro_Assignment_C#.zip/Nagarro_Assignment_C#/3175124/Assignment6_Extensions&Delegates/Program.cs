﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Extensionmethods;

namespace Extensionmethods
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[]
            {1, 3, 5, 6, 8, 9, 10};

            // out each result
            foreach (int i in numbers)
            {
                

                if (i.IsEven())
                {
                    Console.Write("Even number");
                }
                else
                {
                    Console.Write("Odd number");
                }
                Console.Write(" : "+i.ToString() + " \t \n");

                if (i.IsPrimeNumber())
                {
                    Console.Write(i.ToString() + " is Prime Number\n");
                }
                else
                {
                    Console.Write(i.ToString() + " is not a Prime Number\n");
                }
                if (i.IsDivisibleBy())
                    {
                    Console.Write(i.ToString() + " is divisible by 5\n");
                }
                else
                {
                    Console.Write(i.ToString() + " is not divisible by 5\n");
                }

                Console.WriteLine();
            }
        }
    }
}




/*namespace ExtensionMethodSample
{
    public static class SimpleExtensionMethods
    {
        public static bool IsEven(this int i)
        {
            return ((i % 2) == 0);
        }

        public static bool IsPrimeNumber(this int i)
        {
            if (i == 1) return false;
            if (i == 2) return true;

            double boundry = Math.Floor(Math.Sqrt(i));

            for (int j = 2; j <= boundry; ++j)
            {
                if ((i % j) == 0) return false;
            }

            return true;
        }
    }
}*/