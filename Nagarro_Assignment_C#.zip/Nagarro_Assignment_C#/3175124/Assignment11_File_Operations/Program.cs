﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Day4Assignment3Exercise1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insert Directory Path");
            string path = Console.ReadLine();
            if (!Directory.Exists(path))
            {
                Console.WriteLine("Invalid Path!! Please Enter Correct Path");
            }
            else
            {
                FileOperations fo = new FileOperations();
                Console.WriteLine("Text File count: " + Convert.ToString(fo.NumberTextFiles(path, ".txt")));

                Console.WriteLine("\nNumber of Files Per Extension");
                fo.NumberOfFilesPerExtension(path);

                Console.WriteLine("\nTop 5 Largest files");
                fo.Top5LargestFiles(path);

                Console.WriteLine("\nFile with Maximum Length");
                fo.FileWithMaximumLength(path);


            }
            //string root = new FileInfo(Assembly.GetExecutingAssembly().Location).DirectoryName;

            Console.ReadLine();
        }
    }
}
