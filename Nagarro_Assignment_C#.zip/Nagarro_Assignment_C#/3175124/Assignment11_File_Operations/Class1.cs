﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4Assignment3Exercise1
{
    public class FileOperations
    {
        //1.Return the number of text files in the directory(*.txt).
        public int NumberTextFiles(string path, string extn)
        {
            int count = 0;
            DirectoryInfo dinfo = new DirectoryInfo(path);
            FileInfo[] Files = dinfo.GetFiles("*" + extn);
            count = Files.Count();
            return count;
        }

        //2.Return the number of files per extension type.
        public void NumberOfFilesPerExtension(string path)
        {
            List<string> extns = new List<string>();
            foreach (string fs in Directory.GetFiles(path))
            {
                extns.Add(Path.GetExtension(fs));
            }
            extns = (from ext in extns select ext).Distinct().ToList();
            foreach (string extn in extns)
            {
                Console.WriteLine("Extention:" + extn + ", Count:" + Convert.ToString(NumberTextFiles(path, extn)));
            }
        }

        //3.Return the top 5 largest files, along with their file size(use anonymous types).
        public void Top5LargestFiles(string path)
        {
            Dictionary<string, long> FileList = new Dictionary<string, long>();
            foreach (string fs in Directory.GetFiles(path))
            {
                FileInfo info = new FileInfo(fs);
                FileList.Add(info.Name, info.Length);
            }
            var sortedDict = (from files in FileList orderby files.Value descending select files)
                .Take(5)
                .ToDictionary(fs => fs.Key, fs => fs.Value);

            foreach (KeyValuePair<string, long> fss in sortedDict)
            {
                Console.WriteLine("File Name:" + fss.Key + ", Size:" + Convert.ToString(fss.Value));
            }
        }

        //4.Return the file with maximum length.
        public void FileWithMaximumLength(string path)
        {
            Dictionary<string, long> FileList = new Dictionary<string, long>();
            foreach (string fs in Directory.GetFiles(path))
            {
                FileInfo info = new FileInfo(fs);
                FileList.Add(info.Name, info.Length);
            }
            var sortedDict = (from files in FileList orderby files.Value descending select files)
                .Take(1)
                .ToDictionary(fs => fs.Key, fs => fs.Value);

            foreach (KeyValuePair<string, long> fss in sortedDict)
            {
                Console.WriteLine("File Name:" + fss.Key + ", Size:" + Convert.ToString(fss.Value));
            }
        }

    }
}
