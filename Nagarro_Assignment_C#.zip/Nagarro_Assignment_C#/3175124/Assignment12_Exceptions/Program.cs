﻿using System;


namespace Nagarro_Assignment
{
   
    class ExceptionExercise
    {
        static void Main(string[] args)
        {
            bool flag = true;
            int count = 0;

            CustomException obj1 = new CustomException();

            while (flag)
            {
                Console.WriteLine("Enter any number from 1-5: ");

                if (!int.TryParse(Console.ReadLine(), out int userInput))
                {
                    Console.WriteLine("Please enter Integer value");
                    continue;
                }
                count += 1;
                if (count > 5)
                {
                    flag = false;
                    try
                    {
                        obj1.getExceptions(userInput, count);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message.ToString());
                    }
                }

                if (userInput >= 1 && userInput <= 5)
                {
                    string numType = "";
                    numType = userInput == 1 ? "even" : userInput == 2 ? "odd" : userInput == 3 ? "prime" : userInput == 4 ? "negative" : userInput == 5 ? "zero" : "";
                    Console.WriteLine("Enter" + " " + numType + " " + "Number: ");
                    if (!int.TryParse(Console.ReadLine(), out int numerEntered))
                    {
                        Console.WriteLine("Please enter Integer value");
                        continue;
                    }
                    if (!obj1.ValidationMethod(userInput, numerEntered))
                    {
                        try
                        {
                            obj1.getExceptions(userInput, count);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message.ToString());
                        }
                    }
                    else
                    {
                        Console.WriteLine("Success!");
                    }
                }
                else
                {
                    Console.WriteLine("Entered number should be between 1 & 5 ");
                }
                continue;

            }
            Console.ReadLine();
        }
    }


}
