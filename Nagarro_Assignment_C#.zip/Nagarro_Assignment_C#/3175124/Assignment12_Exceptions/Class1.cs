﻿using System;


namespace Nagarro_Assignment
{
    public class CustomException
    {
        public void getExceptions(int inputType, int playCount)
        {
            if (playCount > 5)
            {
                throw new Exception("\nYou have played 5 times.\n");
            }
            else
            {
                switch (inputType)
                {
                    case 1:
                        //Console.WriteLine("Invalid Even Number");
                        throw new Exception("Invalid Even Number");

                    case 2:
                        throw new Exception("Invalid Odd Number");

                    case 3:
                        throw new Exception("Invalid Prime Number");

                    case 4:
                        throw new Exception("Invalid Negative Number");

                    case 5:
                        throw new Exception("Not A Zero");

                    default:
                        return;
                }
            }

        }

        public bool ValidationMethod(int inputType, int number)
        {
            bool result = false;

            switch (inputType)
            {
                case 1:
                    result = number % 2 == 0 ? true : false;
                    break;
                case 2:
                    result = number % 2 != 0 ? true : false;
                    break;
                case 3:
                    int chFlag = 0;
                    for (int i = 2; i <= number / 2; i++)
                    {
                        if (number % i == 0)
                        {
                            chFlag = 1;
                            break;
                        }
                    }
                    result = chFlag == 1 ? false : true;
                    break;
                case 4:
                    result = number < 0 ? true : false;
                    break;
                case 5:
                    result = number == 0 ? true : false;
                    break;
            }
            return result;
        }

    }
}
