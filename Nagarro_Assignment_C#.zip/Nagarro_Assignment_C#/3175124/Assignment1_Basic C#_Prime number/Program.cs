﻿using System;

namespace Nagarro_Assignment
{
    class PrimeNumberInRange
    {
        static void Main(string[] args)
        {
            bool flag = true;
            while (flag)
            {
                Console.Write("Enter Number betweer 2 to 1000: ");
                int num1 = Convert.ToInt16(Console.ReadLine());

                Console.Write("Enter Number betweer 2 to 1000: ");
                int num2 = Convert.ToInt16(Console.ReadLine());

                Console.WriteLine("\n");
                if (num1 > 0 && num2 > 0)
                {
                    if (num1 < num2)
                    {
                        for (int i = num1; i <= num2; i++)
                        {
                            int count = 1;
                            for (int j = 2; j <= i / 2; ++j)
                            {
                                if (i % j == 0)
                                {
                                    count = 0;
                                    break;
                                }
                            }
                            if (count == 1)
                            {
                                Console.WriteLine(i);
                            }
                        }
                        flag = false;
                    }
                    else
                    {
                        Console.WriteLine("Error!! \n");

                    }
                }
                else
                {
                    Console.WriteLine("Error!!\n");
                }
                continue;
            }
            Console.ReadLine();
        }
    }
}
