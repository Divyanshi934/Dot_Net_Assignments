﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace Nagarro_Assignment
{
    public static class ObservableCollection
    {
        enum Actions
        {
            Addition,
            Removal
        }
        public static void Collection()
        {
            ObservableCollection<string> names = new ObservableCollection<string>();
            names.CollectionChanged += CollectionChanged;
            names.Add("A");
            names.Add("B");
            names.Remove("C");
            names.Add("D");
            names.Add("E");
        }
        private static void CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            //Console.WriteLine("Action type: " + e.Action);
            if (e.NewItems != null)
            {
                //Console.WriteLine("Items added: ");
                foreach (var item in e.NewItems)
                {
                    showAction((int)Actions.Addition, Convert.ToString(item));
                }
            }

            if (e.OldItems != null)
            {
                //Console.WriteLine("Items removed: ");
                foreach (var item in e.OldItems)
                {
                    showAction((int)Actions.Removal, Convert.ToString(item));
                }
            }
        }
        private static void showAction(int act, string itm)
        {
            if (act == 0)
            {
                Console.WriteLine("Element " + itm + "  is added in collection.");
              //  Console.WriteLine("Can't see Element " + itm + " because it is removed from collection.");

            }
            else
            {
                Console.WriteLine("Element " + itm + "  is removed from collection");
            }
        }
    }

}
