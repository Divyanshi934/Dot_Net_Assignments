﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nagarro_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            ObservableCollection.Collection();
            Console.ReadLine();
        }
    }
}
