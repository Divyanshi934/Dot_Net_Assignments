﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Nagarro_project
{
    public class EquipmentProperties
    {
        public string Name { get; set; }
        public decimal DistanceMoved { get; set; }
        
        public string EquipmentType { get; set; }
        public int WheelsOfEquipment { get; set; }
        public decimal WeightOfEquipment { get; set; }
        public decimal MaintainenceCost { get; set; }

        public EquipmentProperties(string name, decimal distanceMoved,
            string equipmentType, decimal weightOfEquipment, int wheelsOfEquipment, decimal maintainenceCost)
        {
            this.Name = name;
            this.DistanceMoved = distanceMoved;
            this.EquipmentType = equipmentType;
            this.WheelsOfEquipment = wheelsOfEquipment;
            this.WeightOfEquipment = weightOfEquipment;
            this.MaintainenceCost = maintainenceCost;
        }

        public EquipmentProperties()
        {
        }
    }
    class EquipmentFunctionalities
    {
        List<EquipmentProperties> equipment = new List<EquipmentProperties>();
        public List<EquipmentProperties> CreateEquipment()
        {
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("\nName of Equipment");
                string name = Console.ReadLine().ToUpper();

                Console.WriteLine("\nType of Equipment: mobile/immobile");
                string equipmentType = Console.ReadLine().ToLower();
                decimal weightOfEquipment = 0;
                int wheelsOfEquipment = 0;
                if (equipmentType == "immobile")
                {
                    Console.WriteLine("\nWeight of Equipment");
                    weightOfEquipment = Convert.ToDecimal(Console.ReadLine());

                }
                else
                {
                    Console.WriteLine("\nWheels of Equipment");
                    wheelsOfEquipment = Convert.ToInt32(Console.ReadLine());
                }
                Console.WriteLine("\nDistance Moved by the Equipment");
                decimal.TryParse(Console.ReadLine(), out decimal distanceMoved);
                decimal maintainenceCost = 0;

                if (equipmentType == "mobile")
                {
                    maintainenceCost = wheelsOfEquipment * distanceMoved;
                }
                else
                {
                    maintainenceCost = weightOfEquipment * distanceMoved;
                }

                equipment.Add(new EquipmentProperties(name, distanceMoved, equipmentType, weightOfEquipment, wheelsOfEquipment, maintainenceCost));

                Console.WriteLine("\nDo you want to Add more Equipment? - Yes/No");
                string response = Console.ReadLine().ToUpper();
                if (response == "YES")
                    continue;
                else
                    flag = false;
                break;

            }

            return equipment;
        }

        public List<EquipmentProperties> DeleteEquipment()
        {
            Console.WriteLine("Enter the sequence number of Equipment You Want to Remove: ");
            int.TryParse(Console.ReadLine(), out int equipmentToRemove);
            equipment.RemoveAt(equipmentToRemove);
            return equipment;
        }

        public List<EquipmentProperties> DeleteAllEquipment()
        {
            equipment.Clear();
            return equipment;
        }

        public List<EquipmentProperties> RemoveMobile()
        {
            equipment.Remove(equipment.Single(s => s.EquipmentType == "mobile"));
            Console.WriteLine("Process Completed!\n");
            return equipment;
        }

        public List<EquipmentProperties> RemoveImmobile()
        {
            equipment.Remove(equipment.Single(s => s.EquipmentType == "immobile"));
            Console.WriteLine("Process Completed!\n");
            return equipment;
        }

        public List<EquipmentProperties> MobileEquipments()
        {
            List<EquipmentProperties> mobileEquipment = equipment.Where(o => o.EquipmentType == "mobile").ToList();
            foreach (EquipmentProperties moequi in mobileEquipment)
            {
                Console.WriteLine(String.Format("Name: {0}, Type: {1}, Distance Moved: {2}, Maintainence Cost: {3}",
                   moequi.Name, moequi.EquipmentType, moequi.DistanceMoved, moequi.MaintainenceCost));
            }
            Console.WriteLine();

            return mobileEquipment;
        }

        public List<EquipmentProperties> ImmobileEquipments()
        {
            List<EquipmentProperties> immobileEquipment = equipment.Where(o => o.EquipmentType == "immobile").ToList();
            foreach (EquipmentProperties immoequi in immobileEquipment)
            {
                Console.WriteLine(String.Format("Name: {0}, Type: {1}, Distance Moved: {2}, Maintainence Cost: {3}",
                   immoequi.Name, immoequi.EquipmentType, immoequi.DistanceMoved, immoequi.MaintainenceCost));
            }
            Console.WriteLine();

            return immobileEquipment;
        }

        public List<EquipmentProperties> NotMoved()
        {
            var notMoved = equipment.FindAll(o => o.DistanceMoved == 0);
            foreach (var immoequi in notMoved)
            {
                Console.WriteLine(immoequi);
            }

            return notMoved;
        }

        public EquipmentProperties Ob1 { get; set; } = new EquipmentProperties();

        public List<EquipmentProperties> ShowDetails()
        {
            foreach (EquipmentProperties equip in equipment)
            {
                Console.WriteLine(String.Format("Name: {0}, Type: {1}, Distance Moved: {2}, Maintainence Cost: {3}",
                    equip.Name, equip.EquipmentType, equip.DistanceMoved, equip.MaintainenceCost));
            }
            Console.WriteLine();
            return equipment;
        }

        public List<EquipmentProperties> MoveEquipment()
        {
            Console.WriteLine("Enter the distance of Equipment You Want to move: ");
            decimal.TryParse(Console.ReadLine(), out decimal value);
            Type examType = typeof(EquipmentProperties);
            Console.WriteLine("Enter the sequence number of Equipment You Want to move: ");
            string equipmentName = Console.ReadLine();
            PropertyInfo piInstance = examType.GetProperty("DistanceMoved");
            //object distanceMoved = null;
            piInstance.SetValue(equipmentName, value);

            return equipment;
        }

        public List<EquipmentProperties> ListAll()
        {
            foreach (EquipmentProperties equip in equipment)
            {
                Console.WriteLine(String.Format("Name: {0}, Type: {1}", equip.Name, equip.EquipmentType));
            }
            Console.WriteLine();
            return equipment;

        }
        public List<EquipmentProperties> EndGame()
        {
            Console.WriteLine("---Thanks! Visit Again---");
            return equipment;
        }
    }
    class AdvancedEquipmentInventoryManagementSystem
    {
        static void Main(string[] args)
        {
           
            List<EquipmentProperties> equipment = new List<EquipmentProperties>();
            EquipmentFunctionalities ob1 = new EquipmentFunctionalities();
            bool flag = true;

            while (flag)
            {
                try
                {
                    Console.WriteLine("Choose Type of Operation you want to perform:");
                    Console.WriteLine("\t1. Create Equipment");
                    Console.WriteLine("\t2. Delete Equipment");
                    Console.WriteLine("\t3. Move Equipment");
                    Console.WriteLine("\t4. Show Equipments");
                    Console.WriteLine("\t5. List of All Equipment");
                    Console.WriteLine("\t6. Exit from the System\n");
                    int.TryParse(Console.ReadLine(), out int userChoice);

                    switch (userChoice)
                    {
                        case 1:
                            {
                                equipment = ob1.CreateEquipment();
                                continue;
                            }
                        case 2:
                            {
                                Console.WriteLine("\tChoose appropriate options below");
                                Console.WriteLine("\t\ta. Delete Single Equipments");
                                Console.WriteLine("\t\tb. Delete Mobile Equipments");
                                Console.WriteLine("\t\tc. Delete Immobile Equipments");
                                Console.WriteLine("\t\td. Delete All Equipments");
                                char.TryParse(Console.ReadLine().ToLower(), out char optionChoosed);
                                if (optionChoosed == 'a') { equipment = ob1.DeleteEquipment(); }
                                else if (optionChoosed == 'b') { equipment = ob1.RemoveMobile(); }
                                else if (optionChoosed == 'c') { equipment = ob1.RemoveImmobile(); }
                                else if (optionChoosed == 'd') { equipment = ob1.DeleteAllEquipment(); }
                                else
                                {
                                    Console.WriteLine("Error: Enter Correct options only.");
                                    continue;
                                }
                                continue;
                            }
                        case 3:
                            {
                                equipment = ob1.MoveEquipment();
                                continue;
                            }
                        case 4:
                            {
                                Console.WriteLine("\tChoose appropriate options below");
                                Console.WriteLine("\t\ta. Show All Equipments");
                                Console.WriteLine("\t\tb. Show only Mobile Equipments");
                                Console.WriteLine("\t\tc. Show only Immobile Equipments");
                                Console.WriteLine("\t\td. Show only Equipments Not Moved Yet");
                                char.TryParse(Console.ReadLine().ToLower(), out char optionChoosed);
                                if (optionChoosed == 'a') { equipment = ob1.ShowDetails(); }
                                else if (optionChoosed == 'b') { equipment = ob1.MobileEquipments(); }
                                else if (optionChoosed == 'c') { equipment = ob1.ImmobileEquipments(); }
                                else if (optionChoosed == 'd') { equipment = ob1.NotMoved(); }
                                else
                                {
                                    Console.WriteLine("Error: Enter Correct options only.");
                                    continue;
                                }
                                continue;
                            }
                        case 5:
                            {
                                equipment = ob1.ListAll();
                                continue;
                            }
                        case 6:
                            {
                                equipment = ob1.EndGame();
                                flag = false;
                                break;
                            }
                        default:
                            {
                                Console.WriteLine("Enter the Correct Input");
                                continue;
                            }
                    }
                }
                catch
                {
                    Console.WriteLine("Choose values from above Options only.");

                }

            }
            Console.ReadLine();
        }
    }
}
