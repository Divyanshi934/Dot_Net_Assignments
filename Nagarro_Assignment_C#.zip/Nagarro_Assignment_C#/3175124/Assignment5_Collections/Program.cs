﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Nagarro_Assignment
{
    class DuckProperties
    {
        public string Type { get; set; }
        public bool Flight { get; set; }
        public string Voice { get; set; }
        public int Wings { get; set; }
        public decimal Weight { get; set; }


        public DuckProperties(string type, bool flight, string voice, int wings, decimal weight)
        {
            this.Type = type;
            this.Flight = flight;
            this.Voice = voice;
            this.Wings = wings;
            this.Weight = weight;
        }
    }
    class DuckFunctionalities
    {
        List<DuckProperties> ducks = new List<DuckProperties>();
        public List<DuckProperties> AddDuck()
        {
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("\nEnter Type of Duck");
                string type = Console.ReadLine();

                Console.WriteLine("\nEither this Duck can Fly or Not eg: Yes/No");
                string flt = Console.ReadLine();
                bool flight = flt.ToUpper() == "YES" ? true : false;

                Console.WriteLine("\nEnter Voice of Duck eg. Mild, Strong or Squeak");
                string voice = Console.ReadLine();

                Console.WriteLine("\nEnter Number of wings of Duck eg: 2/4");
                int wings = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("\nEnter weight of Duck eg: 10.00, 25.00");
                decimal weight = Convert.ToDecimal(Console.ReadLine());

                ducks.Add(new DuckProperties(type, flight, voice, wings, weight));

                Console.WriteLine("\nDo you want to Add more Duck? - Yes/No");
                string response = Console.ReadLine().ToUpper();
                if (response == "YES")
                    continue;
                else
                    flag = false;
                break;

            }
            return ducks;
        }

        public List<DuckProperties> RemoveDuck()
        {
            Console.WriteLine("Enter the Sequence number of Duck You Want to Remove: ");
            int.TryParse(Console.ReadLine(), out int duckToRemove);
            ducks.RemoveAt(duckToRemove);
            return ducks;

        }

        public List<DuckProperties> RemoveAllDucks()
        {
            ducks.Clear();
            return ducks;
        }

        public List<DuckProperties> WeightWiseDucks()
        {
            List<DuckProperties> SortedList = ducks.OrderBy(o => o.Weight).ToList();
            foreach (DuckProperties duck in SortedList)
            {
                Console.WriteLine(String.Format("Type: {0}, Flight: {1}, Weight: {2}, Voice: {3}, Wings: {4}", duck.Type, duck.Flight, duck.Weight, duck.Voice, duck.Wings));
            }
            Console.WriteLine();
            return SortedList;

        }

        public List<DuckProperties> WingsWiseDucks()
        {
            List<DuckProperties> SortedList = ducks.OrderBy(o => o.Wings).ToList();
            foreach (DuckProperties duck in SortedList)
            {
                Console.WriteLine(String.Format("Type: {0}, Flight: {1}, Weight: {2}, Voice: {3}, Wings: {4}", duck.Type, duck.Flight, duck.Weight, duck.Voice, duck.Wings));
            }
            Console.WriteLine();
            return SortedList;

        }

        public List<DuckProperties> EndGame()
        {
            Console.WriteLine("END!!");
            return ducks;
        }




    }
    class AdvancedDuckSimulationSystem
    {
        static void Main(string[] args)
        {
            

            List<DuckProperties> ducks = new List<DuckProperties>();

            DuckFunctionalities ob1 = new DuckFunctionalities();



            bool flag = true;

            while (flag)
            {
                try
                {
                    Console.WriteLine("Choose Type of Operation you want to perform:");
                    Console.WriteLine("\t1. Add a Duck");
                    Console.WriteLine("\t2. Remove a Duck");
                    Console.WriteLine("\t3. Remove all Ducks");
                    Console.WriteLine("\t4. Show the Duck List : Weight Wise");
                    Console.WriteLine("\t5. Show the Duck List : Wings Wise");
                    Console.WriteLine("\t6. Exit from the System\n");

                    int.TryParse(Console.ReadLine(), out int userChoice);

                    switch (userChoice)
                    {
                        case 1:
                            ducks = ob1.AddDuck();
                            continue;
                        case 2:
                            {
                                ducks = ob1.RemoveDuck();
                                continue;
                            }
                        case 3:
                            {
                                ducks = ob1.RemoveAllDucks();
                                continue;
                            }
                        case 4:
                            {
                                ducks = ob1.WeightWiseDucks();
                                continue;
                            }
                        case 5:
                            {
                                ducks = ob1.WingsWiseDucks();
                                continue;
                            }
                        case 6:
                            {
                                ducks = ob1.EndGame();
                                flag = false;
                                break;
                            }
                        default:
                            {
                                Console.WriteLine("Enter the Correct Input");
                                continue;
                            }

                    }

                }
                catch
                {
                    Console.WriteLine("Choose values from above Options only.");

                }

            }

            Console.ReadLine();
        }
    }
}
