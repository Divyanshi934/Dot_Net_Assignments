﻿using System;

namespace NagarroAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            PriorityQueue2<string> priorityQueue = new PriorityQueue2<string>(); 
            int choice = -1;
            while (choice != 7)
            {
                Console.WriteLine("1. Enqueue Operation");
                Console.WriteLine("2. Dequeue Operation");
                Console.WriteLine("3. Check object is present in Priority Queue");
                Console.WriteLine("4. Get Peek Element");
                Console.WriteLine("5. Get Highest Priority");
                Console.WriteLine("6. Count Operation");
                Console.WriteLine("7. Exit");
                Console.Write("Enter Your choice: ");
                choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        //enque item
                        int priority;
                        string item;
                        Console.Write("Enter Priority of an Item: ");
                        priority = int.Parse(Console.ReadLine());
                        Console.Write("Enter Item : ");
                        item = Console.ReadLine();
                        priorityQueue.Priority = priority;
                        priorityQueue.Enqueue(item);
                        Console.WriteLine("Enqueued Successfully\n");
                        break;
                    case 2:
                        //dequeue item
                        try
                        {
                            priorityQueue.Dequeue();
                            Console.WriteLine("Dequeued Successfully\n");
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        break;

                    case 3:
                        //check item contains in PriorityQueue
                        string element;
                        Console.Write("Enter Item : ");
                        element = Console.ReadLine();
                        Console.WriteLine("Element Contains : {0}", priorityQueue.Contains(element));
                        Console.WriteLine();
                        break;
                    case 4:
                        //get peek element
                        try
                        {
                            Console.WriteLine("Peek element : {0}", priorityQueue.Peek());
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        Console.WriteLine();
                        break;
                    case 5:
                        //get highrest priority
                        try
                        {
                            Console.WriteLine("Highest Priority : {0} ", priorityQueue.GetHighestPriority());
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        Console.WriteLine();
                        break;
                    case 6:
                        //get count
                        Console.WriteLine("Number of Elemets : {0}", priorityQueue.Count);
                        Console.WriteLine();
                        break;
                    case 7:
                        //exit
                        break;
                }
            }
            Console.ReadKey();
        }
    }

}
