﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace NagarroAssignment
{


    class PriorityQueue2<T> : IPriority where T : IEquatable<T>
    {
        //dictionary: for storing content according to priority
        private IDictionary<int, IList<T>> elements;

        public PriorityQueue2()
        {
            elements = new Dictionary<int, IList<T>>();
        }
        public PriorityQueue2(IDictionary<int, IList<T>> elements) : this()
        {
            this.elements = elements;
        }
        //count: property for counting the elements 
        public int Count
        {
            get
            {
                int count = 0;
                foreach (KeyValuePair<int, IList<T>> l in elements)
                {
                    count += l.Value.Count;
                }

                return count;
            }
        }
        //Priority property
        public int Priority { get; set; }

        //contains: method for checking object in dictionary
        public bool Contains(T items)
        {
            foreach (var list in elements)
            {
                foreach (T element in list.Value)
                {
                    if (element.Equals(items))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public T Dequeue()
        {
            if (elements.Count > 0)
            {
                //getting highest priority
                int highestPriority = GetHighestPriority();

                T element = elements[highestPriority][0];
                //removing highest priority elements
                elements[highestPriority].Remove(element);

                //if no object in priority then remove priority from dictionary
                if (elements[highestPriority].Count == 0)
                {
                    elements.Remove(highestPriority);
                }
                return element;
            }
            else
            {
                throw new Exception("No element present....");
            }
        }
        public void Enqueue(T item)
        {
            //check: that key contains in dictionary or not
            bool check = false;
            foreach (var key in elements.Keys)
            {
                if (Priority == key)
                {
                    check = true;
                }
            }
            //add elements according to priority
            if (!check)
            {
                elements[Priority] = new List<T>();
            }
            elements[Priority].Add(item);
            Console.WriteLine("Inserted ");
        }
        public T Peek()
        {
            if (elements.Count > 0)
            {
                return elements[GetHighestPriority()][0];
            }
            else
            {
                throw new Exception("No element present...");
            }
        }
        public int GetHighestPriority()
        {
            List<int> keys = elements.Keys.ToList();
            keys = keys.OrderByDescending(element => element)
                              .ToList();
            if (keys.Count == 0)
            {
                throw new Exception("No element present...");
            }
            return keys[0];
        }
    }
}