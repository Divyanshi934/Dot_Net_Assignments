﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nagarro_Assignment
{
    class LambdaDelegates
    {
        public delegate bool Delegate(int element); 

        
        public delegate List<int> Finding3K(int K); 

        public delegate void checkAvlbl(int ele);

        static void Main(string[] args)
        {
            List<int> number = new List<int>
            {
                1,2,3,4,5,6,7,8,9,10,11,12,13,14,15

            };
            // 1.	Find odd - Lambda Expression – without curly brackets
            List<int> oddNumbers = number.Where(x => x % 2 != 0).ToList();
            Console.WriteLine("Odd Numbers without Curly Braces");
            foreach (int ab in oddNumbers)
                Console.WriteLine(ab);
            
            //2.	Find Even - Lambda Expression – with curly brackets
            Console.WriteLine("\n Even Numbers with Curly Braces");
            foreach (int ab in number.Where(x =>
            {
                if (x % 2 == 0)
                    return true;
                else
                    return false;
            }
                ))
            {
                Console.WriteLine(ab);
            }
            
            //3.	Find Prime – Anonymous Method
            Console.WriteLine("\n Prime Numbers - Anonymous Method");

            int uptoNumber = 10; // upto we require a Prime Number.

            Func<int, IEnumerable<int>> primeNumbers = max =>
                 from i in Enumerable.Range(2, max - 1)
                 where Enumerable.Range(2, i - 2).All(j => i % j != 0)
                 select i;
            IEnumerable<int> result = primeNumbers(uptoNumber); // Using uptoNumber here
            foreach (int i in result)
            {
                Console.WriteLine(i);
            }
            
            //4.	Find Prime Another – Lambda Expression
            Console.WriteLine("\nPrime Numbers using Lambda Expression");
            IEnumerable<int> primes = from num in Enumerable.Range(1, uptoNumber / 2)
                                      where (
                                          (Func<int, bool>)(n =>
                                          {
                                              for (int i = 3; i * i <= n; i += 2)
                                                  if (n % i == 0) return false;
                                              return true;
                                          }
                                          )
                                      )(2 * num + 1)
                                      select 2 * num + 1;
            IEnumerable<int> res = primeNumbers(uptoNumber); // Using uptoNumber here
            foreach (int i in res)
            {
                Console.WriteLine(i);
            }

            //5.	Find Elements Greater Than Five – Method Group Conversion Syntax
            Console.WriteLine("\nElements Greater Than 5 - Method Group Conversion Syntax");

            Delegate del = (int element) => element > 5;
            IEnumerable<int> query = number.Where(x => del(x));

            foreach (int i in query)
            {
                Console.WriteLine(i);
            }
            
            //6.	Find element Less than Five – Delegate Object in Where – Method Group Conversion Syntax in Constructor of Object
            Console.WriteLine("\nElements less Than 5 using Method Group Conversion Syntax");

            Delegate deleg = new Delegate((int element) => element < 5);
            IEnumerable<int> qry = number.Where(x => deleg(x));

            foreach (int i in qry)
            {
                Console.WriteLine(i);
            }

            // 7.Find 3k – Delegate Object in Where –Lambda Expression in Constructor of Object

            Console.WriteLine("\n3K series using Lambda Expression in Constructor");
            List<int> series1 = new List<int>();
            int sum = 0;
            Finding3K series3K = (K) =>
            {

                for (int i = 1; i <= 3; i++)
                {
                    series1.Add((int)Math.Pow(i, K));
                }
                return series1;
            };
            IEnumerable<int> result1 = series3K(4); // Update the value of K here.

            foreach (int i in result1)
            {
                Console.WriteLine(i);
            }

             // 8.Find 3k+1 – Delegate Object in Where –Lambda Expression in Constructor of Object

            Console.WriteLine("\n3K+1 series using Anonymous method in Constructor");
            List<int> series2 = new List<int>();
            Finding3K series3K1 = delegate (int K)
            {
                for (int i = 1; i <= 3; i++)
                {
                    series2.Add((int)Math.Pow(i, K + 1));

                }
                return series2;
            };
            IEnumerable<int> result2 = series3K1(4); // Update the value of K here.

            foreach (int i in result2)
            {
                Console.WriteLine(i);
            }

             // 9. Find 3k + 2 - Delegate Object in Where–Lambda Expression Assignment

            Console.WriteLine("\n3K+2 series using Lambda Expression");
            List<int> series3 = new List<int>();
            Finding3K series3K2 = (K) => {
                for (int i = 1; i <= 3; i++)
                {
                    series3.Add((int)Math.Pow(i, K + 2));
                }
                return series3;
            };
            IEnumerable<int> result3 = series3K2(4); // Update the value of K here.
            foreach (int i in result3)
            {
                Console.WriteLine(i);
            }

             // 10. Find anything - Delegate Object in Where – Anonymous Method Assignment

            Console.WriteLine("\nFind Anything using Anonymous Method");

            List<int> myList = new List<int>() { 100, 26, 31, 24, 53, 63, 74, 84 };

            checkAvlbl object1 = delegate (int ele)
            {
                //  List<int> myList = new List<int>() { 100, 26, 31, 24, 53, 63, 74, 84 };
                if (myList.Contains(ele))
                {
                    Console.WriteLine("This list Contains the entered value: {0}", ele);
                }
                else
                    Console.WriteLine("This list do not Contains the entered value");
            };

            object1(26);


            // 11. Find anything - Delegate Object in Where – Method Group Conversion Assignment

            Console.WriteLine("\nFind Anything using– Method Group Conversion Assignment");


            checkAvlbl object2 = (int ele) =>
            {

                if (myList.Contains(ele))
                {
                    Console.WriteLine("This list Contains the entered value: {0}", ele);
                }
                else
                    Console.WriteLine("This list do not Contains the entered value: {0}", ele);
            };

            object2(96);
            Console.ReadLine();
        }


    }
}
