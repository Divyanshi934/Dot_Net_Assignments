﻿using System;
using System.Collections.Generic;


namespace StackImplementation
{
    class Stack
    {
        private int[] items;
        private int top;
        private int max;



        public Stack(int size)
        {

            if (size < 0)
            {
                throw new ArgumentOutOfRangeException();
            }

            items = new int[size];
            top = -1;
            max = size;
        }




        public void push(int item)
        {
            if (top == max - 1)
            {
                Console.WriteLine("Stack Overflow");
                return;
            }
            else
            {
                items[++top] = item;
            }
        }

        public int pop()
        {
            if (top == -1)
            {
                Console.WriteLine("Stack is Empty");
                return -1;
            }
            else
            {
                Console.WriteLine("{0} popped from stack ", items[top]);
                return items[top--];
            }
        }

        public void peek()
        {
            if (top == -1)
            {
                Console.WriteLine("Stack is Empty");

            }
            else
            {

                Console.WriteLine(items[top]);
            }
        }

        public int size()
        {
            int count = 0;
            for (int i = 0; i <= top; i++)
            {
                count = count + 1;
            }
            return count;

        }


        public bool contains(int item)
        {

            for (int i = 0; i <= top; i++)
            {
                if (items[i] == item)
                {
                    return true;
                }

            }

            return false;
        }


        public void printStack()
        {
            if (top == -1)
            {
                Console.WriteLine("Stack is Empty");
                return;
            }
            else
            {
                for (int i = 0; i <= top; i++)
                {
                    Console.WriteLine("{0} pushed into stack", items[i]);
                }
            }
        }


        public IEnumerable<int> GetStack()
        {

            foreach (var items in items)
            {

                yield return items;
            }




        }

    }
}
