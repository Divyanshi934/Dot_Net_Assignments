﻿using System;
using System.Collections.Generic;


namespace StackImplementation
{



    class Program
    {
        public static void Main(String[] args)
        {
            int size, item, choice;
            const string exit = "exit", yes = "yes";
            try
            {


                Console.WriteLine("Enter the size of stack");
                int.TryParse(Console.ReadLine(), out size);
                Stack stack = new Stack(size);
                Stack st = new Stack(size);

                string option;

                do
                {
                    Console.WriteLine("Enter your choice");
                    Console.WriteLine("1.Push");
                    Console.WriteLine("2.Pop");
                    Console.WriteLine("3.Peek");
                    Console.WriteLine("4.Contains");
                    Console.WriteLine("5.Size");
                    Console.WriteLine("6.Iterator");
                    Console.WriteLine("7.Reverse");
                    Console.WriteLine("8.Print");
                    int.TryParse(Console.ReadLine(), out choice);
                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("Enter the element to be inserted");
                            int.TryParse(Console.ReadLine(), out item);
                            stack.push(item);
                            break;
                        case 2:
                            stack.pop();
                            break;
                        case 3:
                            stack.peek();

                            break;
                        case 4:
                            Console.WriteLine("Enter the element to be searched");
                            int.TryParse(Console.ReadLine(), out item);
                            stack.contains(item);
                            break;
                        case 5:
                            Console.WriteLine("Total no of items present in the list " + stack.size());
                            break;
                        case 6:
                            IEnumerable<int> my_slist = stack.GetStack();


                            foreach (var i in my_slist)
                            {
                                Console.WriteLine("Item in stack  " + i);
                            }
                            break;
                        case 7:
                            Console.WriteLine("Reversed stack is");
                            while (stack.size() != 0)
                            {
                                st.push(stack.pop());
                            }

                            break;
                        case 8:
                            stack.printStack();
                            break;
                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }

                    Console.WriteLine("Do you want to Continue,Press Exit to stop and y to continue");
                    option = Console.ReadLine().ToLower();


                } while (option != exit && option == yes);



            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Size is less than or equal to zero");
            }





        }
    }
}
