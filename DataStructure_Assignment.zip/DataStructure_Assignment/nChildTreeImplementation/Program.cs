﻿using System;


namespace nChildTreeImplementation
{
    class Program
    {
        public static void Main(String[] args)
        {
            nChildTree tree = new nChildTree();


            Console.WriteLine("Tree has following elements inserted in it\n");
            tree.insert(tree.root);
            tree.iteratorBFS(tree.root);



            int choice;
            const string exit = "exit", yes = "yes";

            string option;
            do
            {
                Console.WriteLine("\nEnter your choice");
                Console.WriteLine("1.Get Elements by value");
                Console.WriteLine("2.Get Elements by level");
                Console.WriteLine("3.Contains");
                Console.WriteLine("4.Iterator Breadth First");
                Console.WriteLine("5.Iterator Depth First");
                Console.WriteLine("6.Print Breadth First");
                Console.WriteLine("7.Print Depth First");

                try
                {
                    string input = Console.ReadLine();
                    bool flag = int.TryParse(input, out choice);
                    if (flag == false)
                    {
                        throw new InvalidOperationException();
                    }

                    switch (choice)
                    {
                        case 1:

                            Console.WriteLine("Enter the value");
                            int item = Convert.ToInt32(Console.ReadLine());
                            tree.getElementbyValue(tree.root, item);

                            break;
                        case 2:

                            Console.WriteLine("Enter the level");
                            int level = Convert.ToInt32(Console.ReadLine());
                            tree.getElementByLevel(tree.root, level);
                            break;
                        case 3:
                            Console.WriteLine("Enter the Node value to be found");
                            int value = Convert.ToInt32(Console.ReadLine());

                            if (tree.contains(tree.root, value))
                            {
                                Console.WriteLine("element found");
                            }
                            else
                            {
                                Console.WriteLine("element not found");
                            }
                            break;
                        case 4:
                            Console.WriteLine("Iterator BFS");

                            tree.iteratorBFS(tree.root);

                            break;
                        case 5:
                            Console.WriteLine("Iterator DFS");

                            tree.iteratorDFS(tree.root);
                            break;
                        case 6:
                            Console.WriteLine("\nBreadth First Search");
                            Console.Write(tree.root.key + " ");
                            tree.breadthFirstSearch(tree.root);
                            break;
                        case 7:
                            Console.WriteLine("\nDepth First Search");
                            tree.depthFirstSearch(tree.root);
                            break;

                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }
                }
                catch (InvalidOperationException)
                {
                    Console.WriteLine("Choice entered should be a integer value");
                }

                Console.WriteLine("\nDo you want to Continue,Press Exit to stop and yes to continue");
                option = Console.ReadLine().ToLower();


            } while (option != exit && option == yes);



            Console.ReadKey();
        }
    }


}

