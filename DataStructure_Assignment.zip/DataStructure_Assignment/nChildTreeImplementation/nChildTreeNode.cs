﻿using System;
using System.Collections.Generic;


namespace nChildTreeImplementation
{
    class nChildTreeNode
    {

        public int key;
        public List<nChildTreeNode> child = new List<nChildTreeNode>();


        public nChildTreeNode(int data)
        {
            key = data;

        }





    }
}
