﻿using System;
using System.Collections.Generic;

using System.Threading.Tasks;

namespace nChildTreeImplementation
{
    class nChildTree
    {

        public nChildTreeNode root = new nChildTreeNode(40);


        public void insert(nChildTreeNode root)
        {

            root.child.Add(new nChildTreeNode(10));
            root.child.Add(new nChildTreeNode(19));
            root.child.Add(new nChildTreeNode(12));
            root.child.Add(new nChildTreeNode(16));
            root.child[0].child.Add(new nChildTreeNode(79));
            root.child[0].child.Add(new nChildTreeNode(98));
            root.child[0].child.Add(new nChildTreeNode(22));
            root.child[1].child.Add(new nChildTreeNode(64));
            root.child[1].child.Add(new nChildTreeNode(27));
            root.child[2].child.Add(new nChildTreeNode(89));
            root.child[2].child.Add(new nChildTreeNode(35));
            root.child[3].child.Add(new nChildTreeNode(47));

        }

        public void iteratorBFS(nChildTreeNode root)
        {
            if (root == null)
                return;

            Queue<nChildTreeNode> queueu = new Queue<nChildTreeNode>();
            queueu.Enqueue(root);
            while (queueu.Count != 0)
            {
                int size = queueu.Count;


                while (size > 0)
                {

                    nChildTreeNode p = queueu.Peek();
                    queueu.Dequeue();
                    Console.Write(p.key + " ");


                    for (int i = 0; i < p.child.Count; i++)
                        queueu.Enqueue(p.child[i]);
                    size--;
                }
                Console.WriteLine();


            }


        }

        public void getElementByLevel(nChildTreeNode root, int c)
        {
            if (root == null)
                return;

            Queue<nChildTreeNode> queueu = new Queue<nChildTreeNode>(); // Create a queue
            queueu.Enqueue(root); // Enqueue root 
            int level = 0;
            while (queueu.Count != 0)
            {
                int size = queueu.Count;


                while (size > 0)
                {

                    nChildTreeNode p = queueu.Peek();
                    queueu.Dequeue();
                    if (level == c)
                        Console.Write(p.key + " ");


                    for (int i = 0; i < p.child.Count; i++)
                        queueu.Enqueue(p.child[i]);
                    size--;

                }
                level = level + 1;


            }


        }

        public void iteratorDFS(nChildTreeNode root)
        {


            Stack<nChildTreeNode> stack = new Stack<nChildTreeNode>();


            stack.Push(root);


            while (stack.Count != 0)
            {


                nChildTreeNode curr = stack.Pop();


                if (curr != null)
                {
                    Console.Write(curr.key + " ");

                    for (int i = curr.child.Count - 1; i >= 0; i--)
                    {
                        stack.Push(curr.child[i]);
                    }
                }
            }
        }

        public bool contains(nChildTreeNode root, int x)
        {


            if (root == null)
                return false;


            Queue<nChildTreeNode> queueu = new Queue<nChildTreeNode>();
            queueu.Enqueue(root);

            while (queueu.Count != 0)
            {
                int size = queueu.Count;


                while (size > 0)
                {


                    nChildTreeNode p = queueu.Peek();
                    queueu.Dequeue();
                    int c = 0;
                    if (p.key == x)
                    {

                        return true;
                    }


                    for (int i = 0; i < p.child.Count; i++)
                    {

                        queueu.Enqueue(p.child[i]);


                    }
                    size--;
                }
            }

            return false;

        }

        public bool getElementbyValue(nChildTreeNode root, int x)
        {


            if (root == null)
                return true;


            Queue<nChildTreeNode> queueu = new Queue<nChildTreeNode>();
            queueu.Enqueue(root);

            while (queueu.Count != 0)
            {
                int size = queueu.Count;


                while (size > 0)
                {


                    nChildTreeNode p = queueu.Peek();
                    queueu.Dequeue();
                    int c = 0;
                    if (p.key == x)
                    {

                        if (p.child.Count == 0)
                        {
                            Console.WriteLine("No childrens of given node");
                            c = 1;
                        }
                        if (c != 1)
                        {
                            Console.WriteLine("No. of childrens of given node");
                            for (int i = 0; i < p.child.Count; i++)
                            {
                                Console.WriteLine(p.child[i].key);
                            }
                            return true;
                        }
                    }


                    for (int i = 0; i < p.child.Count; i++)
                    {

                        queueu.Enqueue(p.child[i]);


                    }
                    size--;
                }
            }

            return false;

        }


        public void depthFirstSearch(nChildTreeNode node)
        {
            if (node == null)
                return;


            int total = node.child.Count;


            for (int i = 0; i < total - 1; i++)
                depthFirstSearch(node.child[i]);


            Console.Write("" + node.key + " ");


            if (total > 0)
                depthFirstSearch(node.child[total - 1]);
        }

        public void breadthFirstSearch(nChildTreeNode root)
        {
            if (root == null)


                for (int i = 0; i < root.child.Count; i++)
                    Console.Write(((nChildTreeNode)root.child[i]).key + " ");


            for (int i = 0; i < root.child.Count; i++)
                breadthFirstSearch((nChildTreeNode)root.child[i]);



        }



    }
}
