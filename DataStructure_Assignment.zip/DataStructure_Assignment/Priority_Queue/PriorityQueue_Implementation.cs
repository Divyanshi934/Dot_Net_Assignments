﻿using System;
using System.Collections.Generic;


namespace PriorityQueueImplementation
{
    class PriorityQueue
    {

        public Node head;
        public class Node
        {
            public int data;


            public int priority;

            public Node next;

            public Node(int d, int p)
            {
                data = d;
                next = null;
                priority = p;

            }
        }

        public void enqueue(int new_data, int priority)
        {
            Node new_node = new Node(new_data, priority);
            Node start = head;

            if (head == null)
            {
                head = new Node(new_data, priority);
                return;
            }


            new_node.next = null;




            if (head.priority > priority)
            {

                new_node.next = head;
                head = new_node;

            }
            else
            {


                while (start.next != null &&
                    start.next.priority < priority)
                {
                    start = start.next;
                }


                new_node.next = start.next;
                start.next = new_node;
            }
        }

        public void dequeue()
        {
            if (getCount() == 0) throw new InvalidOperationException();
            Node node = head;
            head = head.next;

        }

        public int peek()
        {
            if (getCount() == 0) throw new InvalidOperationException();
            return head.data;
        }

        public void printQueue()
        {
            Node tnode = head;
            while (tnode != null)
            {
                Console.Write("\n" + tnode.data + " ");
                tnode = tnode.next;
            }
        }

        public void reverseQueue()
        {
            Node prev = null, current = head, next = null;
            while (current != null)
            {
                next = current.next;
                current.next = prev;
                prev = current;
                current = next;
            }
            head = prev;
            printQueue();
        }

        public IEnumerable<int> getQueue()
        {



            Node tnode = head;
            while (tnode != null)
            {
                yield return tnode.data; ;
                tnode = tnode.next;
            }


        }

        public bool contains(int x)
        {
            Node current = head;
            while (current != null)
            {
                if (current.data == x)
                    return true;
                current = current.next;
            }
            return false;
        }

        public int getCount()
        {
            int count = 0;
            Node current = head;
            while (current != null)
            {
                count++;
                current = current.next;
            }
            return count;
        }

    }
}
