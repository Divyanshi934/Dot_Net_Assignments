﻿using System;
using System.Collections.Generic;


namespace PriorityQueueImplementation
{
    class Program
    {
        static void Main(string[] args)
        {
            PriorityQueue pq = new PriorityQueue();
            int top, choice;
            const string exit = "exit", yes = "yes";

            string option;
            do
            {
                Console.WriteLine("Enter your choice");
                Console.WriteLine("1.Enqueue");
                Console.WriteLine("2.Dequeue");
                Console.WriteLine("3.Peek");
                Console.WriteLine("4.Contains");
                Console.WriteLine("5.Size");
                Console.WriteLine("6.Iterator");
                Console.WriteLine("7.Reverse");
                Console.WriteLine("8.Print");
                try
                {
                    bool flag = int.TryParse(Console.ReadLine(), out choice);

                    if (flag == false)
                    {
                        throw new InvalidOperationException();
                    }

                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("Enter the element to be inserted");
                            int item = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter the priority of element ");
                            int priority = Convert.ToInt32(Console.ReadLine());
                            pq.enqueue(item, priority);
                            break;
                        case 2:
                            try
                            {
                                pq.dequeue();
                            }
                            catch (InvalidOperationException)
                            {
                                Console.WriteLine("Queue is empty");
                            }
                            break;
                        case 3:
                            try
                            {


                                top = pq.peek();
                                Console.WriteLine("Element at front " + top);

                            }
                            catch (InvalidOperationException)
                            {
                                Console.WriteLine("Queue is empty");
                            }
                            break;
                        case 4:
                            Console.WriteLine("Enter the element to be searched");
                            item = Convert.ToInt32(Console.ReadLine());
                            pq.contains(item);
                            break;
                        case 5:
                            Console.WriteLine("Total no of elements present in the list " + pq.getCount());
                            break;
                        case 6:
                            IEnumerable<int> my_slist = pq.getQueue();


                            foreach (var i in my_slist)
                            {
                                Console.WriteLine("Item in Queue " + i);
                            }
                            break;
                        case 7:
                            Console.WriteLine("Reversed queue is");
                            pq.reverseQueue();
                            break;
                        case 8:
                            Console.WriteLine("Priority queue is");
                            pq.printQueue();
                            break;
                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }


                }
                catch (InvalidOperationException)
                {
                    Console.WriteLine("Choice should be an integer value");
                }
                Console.WriteLine("\nDo you want to Continue,Press Exit to stop and yes to continue");
                option = Console.ReadLine().ToLower();


            } while (option != exit && option == yes);



            Console.ReadLine();
        }
    }
}
