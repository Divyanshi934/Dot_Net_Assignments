﻿using System;
using System.Collections.Generic;


namespace hashTableImplementation
{
    class hashTable
    {
        class hashnode
        {
            int key;
            string data;
            hashnode next;
            public hashnode(int key, string data)
            {
                this.key = key;
                this.data = data;
                next = null;
            }
            public int getkey()
            {
                return key;
            }
            public string getdata()
            {
                return data;
            }
            public void nextNode(hashnode node)
            {
                next = node;
            }
            public hashnode getNode()
            {
                return this.next;
            }
        }

        hashnode[] elements;
        public int size;

        public hashTable(int max)
        {
            if (max < 0)
            {
                throw new ArgumentOutOfRangeException();
            }
            size = max;
            elements = new hashnode[size];

            for (int i = 0; i < size; i++)
            {
                elements[i] = null;
            }
        }
        public void insert(int key, string data)
        {
            hashnode newNode = new hashnode(key, data);
            int hash = key % size;
            //while (elements[hash] != null && elements[hash].getkey() % size != key % size)
            //{
            //    hash = (hash + 1) % size;
            //}
            if (elements[hash] != null && hash == elements[hash].getkey() % size)
            {

                newNode.nextNode(elements[hash].getNode());
                elements[hash].nextNode(newNode);
                return;
            }
            else
            {

                elements[hash] = newNode;
                return;
            }
        }
        public string retrieve(int key)
        {
            int hash = key % size;
            //while (elements[hash] != null && elements[hash].getkey() % size != key % size)
            //{
            //    hash = (hash + 1) % size;
            //}
            hashnode current = elements[hash];
            while (current.getkey() != key && current.getNode() != null)
            {
                current = current.getNode();
            }
            if (current.getkey() == key)
            {
                return current.getdata();
            }
            else
            {
                return "No element with given key";
            }
        }
        public void delete(int key)
        {
            int hash = key % size;
            //while (elements[hash] != null && elements[hash].getkey() % size != key % size)
            //{
            //    hash = (hash + 1) % size;
            //}
            // a current node pointer used for traversal, currently points to the head
            hashnode current = elements[hash];
            bool removed = false;
            while (current != null)
            {
                if (current.getkey() == key)
                {
                    elements[hash] = current.getNode();
                    Console.WriteLine("The value at particular key is deleted");
                    removed = true;
                    break;
                }

                if (current.getNode() != null)
                {
                    if (current.getNode().getkey() == key)
                    {
                        hashnode newNext = current.getNode().getNode();
                        current.nextNode(newNext);
                        Console.WriteLine("The value at particular key is deleted");
                        removed = true;
                        break;
                    }
                    else
                    {
                        current = current.getNode();
                    }
                }

            }

            if (!removed)
            {
                Console.WriteLine("There is no value for particular key");
                return;
            }
        }
        public void print()
        {
            hashnode current = null;
            for (int i = 0; i < size; i++)
            {
                current = elements[i];
                while (current != null)
                {
                    Console.Write(current.getdata() + " ");

                    current = current.getNode();
                }

            }
        }
        public IEnumerable<string> GethashTable()
        {
            // Creating and adding elements in list
            hashnode current = null;
            for (int i = 0; i < size; i++)
            {
                current = elements[i];
                while (current != null)
                {
                    yield return current.getdata();
                    current = current.getNode();
                }

            }




        }
        public void contains(string st)
        {
            hashnode current = null;
            int flag = 0;
            for (int i = 0; i < size; i++)
            {
                current = elements[i];
                while (current != null)
                {

                    if (current.getdata() == st)
                    {
                        Console.WriteLine("Element Found");
                        flag = 1;
                        break;
                    }
                    current = current.getNode();
                }



            }
            if (flag == 0)
            {
                Console.WriteLine("Element not found");
            }
        }

        public int count()
        {
            hashnode current = null;
            int count = 0;
            for (int i = 0; i < size; i++)
            {
                current = elements[i];
                while (current != null)
                {
                    if (current.getdata() != "")
                        count = count + 1;
                    current = current.getNode();
                }

            }

            return count;

        }
    }
}
