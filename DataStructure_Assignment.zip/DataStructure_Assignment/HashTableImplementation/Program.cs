﻿using System;
using System.Collections.Generic;


namespace hashTableImplementation
{
    class Program
    {
        static void Main(string[] args)
        {

            int size, choice, key;
            const string exit = "exit", yes = "yes";
            string option, value;

            try
            {


                Console.WriteLine("Enter the size");
                int.TryParse(Console.ReadLine(), out size);
                hashTable hash = new hashTable(size);


                do
                {


                    Console.WriteLine("Enter your choice");
                    Console.WriteLine("1.Insert");
                    Console.WriteLine("2.Delete");
                    Console.WriteLine("3.Contain");
                    Console.WriteLine("4.Get value by key");
                    Console.WriteLine("5.Size");
                    Console.WriteLine("6.Iterator");
                    Console.WriteLine("7.Print");

                    Console.WriteLine("Enter your choice");
                    try
                    {
                        bool flag = int.TryParse(Console.ReadLine(), out choice);

                        if (flag == false)
                        {
                            throw new InvalidOperationException();
                        }

                        switch (choice)
                        {
                            case 1:
                                Console.WriteLine("Enter key");

                                int.TryParse(Console.ReadLine(), out key);

                                Console.WriteLine("Enter value");
                                value = Console.ReadLine();
                                hash.insert(key, value);
                                break;
                            case 2:
                                Console.WriteLine("Enter key");

                                int.TryParse(Console.ReadLine(), out key);
                                hash.delete(key);
                                break;
                            case 3:
                                Console.WriteLine("Enter value");
                                value = Console.ReadLine();
                                hash.contains(value);
                                break;
                            case 4:
                                Console.WriteLine("Enter key");

                                int.TryParse(Console.ReadLine(), out key);
                                string retString = hash.retrieve(key);
                                Console.WriteLine(retString);
                                break;
                            case 5:

                                Console.WriteLine("Size of hash table " + hash.count());
                                break;
                            case 6:
                                IEnumerable<string> my_slist = hash.GethashTable();

                                // Display the elements return from iteration
                                foreach (var str in my_slist)
                                {
                                    Console.WriteLine("Item in hash elements " + str);
                                }
                                break;
                            case 7:
                                hash.print();
                                break;
                            default:
                                Console.WriteLine("Invaid Choice");
                                break;

                        }
                    }
                    catch (InvalidOperationException)
                    {
                        Console.WriteLine("Choice should be an integer value");
                    }
                    Console.WriteLine("\nDo you want to Continue,Press Exit to stop and yes to continue");
                    option = Console.ReadLine().ToLower();

                } while (option != exit && option == yes);




            }

            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Size is less than or equal to zero");
            }


            Console.ReadKey();

        }
    }
}
