﻿using System;
using System.Collections.Generic;


namespace LinkedListImplementation
{



    class Program
    {



        public static void Main(String[] args)
        {

            LinkedList linkedList = new LinkedList();


            int choice, item, position;

            string option;

            do
            {
                Console.WriteLine("Enter your choice");
                Console.WriteLine("1.Insert");
                Console.WriteLine("2.Insert At Position");
                Console.WriteLine("3.Delete");
                Console.WriteLine("4.Delete At position");
                Console.WriteLine("5.Get Middle Element");
                Console.WriteLine("6.Size");
                Console.WriteLine("7.Print List");
                Console.WriteLine("8.Reverse List");
                Console.WriteLine("9.Iterator");

                try
                {
                    bool flag = int.TryParse(Console.ReadLine(), out choice);

                    if (flag == false)
                    {
                        throw new InvalidOperationException();
                    }
                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("Enter the element to be inserted");
                            int.TryParse(Console.ReadLine(), out item);
                            linkedList.insert(item);
                            break;
                        case 2:
                            Console.WriteLine("Enter the element to be inserted");
                            int.TryParse(Console.ReadLine(), out item);
                            Console.WriteLine("Enter the position ");
                            int.TryParse(Console.ReadLine(), out position);
                            linkedList.insertAtPosition(position, item);
                            break;




                        case 3:
                            try
                            {
                                linkedList.delete();
                            }
                            catch (InvalidOperationException)
                            {
                                Console.WriteLine("No element in linked list");
                            }
                            break;
                        case 4:
                            Console.WriteLine("Enter the position");

                            int.TryParse(Console.ReadLine(), out position);
                            try
                            {

                                linkedList.deleteAtPosition(position);

                            }
                            catch (InvalidOperationException)
                            {
                                Console.WriteLine("No element in linked list");
                            }
                            break;
                        case 5:
                            linkedList.printMiddle(linkedList.head);
                            break;
                        case 6:
                            Console.WriteLine("Total No of elements in list " + linkedList.getCount(linkedList.head));
                            break;



                        case 7:
                            linkedList.printList();
                            break;
                        case 8:
                            Console.WriteLine("Reversed list is");
                            linkedList.reverseList();
                            break;

                        case 9:
                            IEnumerable<int> my_slist = linkedList.GetList();


                            foreach (var i in my_slist)
                            {
                                Console.WriteLine("Item in linked list " + i);
                            }
                            break;


                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }
                }
                catch (InvalidOperationException)
                {
                    Console.WriteLine("Choice entered should be an integer value");
                }

                Console.WriteLine("\nDo you want to Continue,Press Exit to stop and yes to continue");
                option = Console.ReadLine().ToLower();


            } while (option != "exit" && option == "yes");



            Console.ReadKey();








        }
    }


}
