﻿using System;
using System.Collections.Generic;


namespace LinkedListImplementation
{

    class LinkedList
    {


        public Node head;

        public class Node
        {
            public int data;
            public Node next;
            public Node(int d)
            {
                data = d;
                next = null;
            }
        }




        public void insert(int new_data)
        {
            Node new_node = new Node(new_data);


            if (head == null)
            {
                head = new Node(new_data);
                return;
            }


            new_node.next = null;


            Node last = head;
            while (last.next != null)
                last = last.next;


            last.next = new_node;
            return;
        }




        public void insertAtPosition(int index, int new_data)
        {
            Node current = head;
            Node temp = head;
            int count = 0; /* index of Node we are
                        currently looking at */
            if (index == 0)
            {

                Node new_node = new Node(new_data);
                new_node.next = head;
                head = new_node;

                Console.WriteLine("Node inserted");
            }
            else if (index == (getCount(head)))
            {
                insert(new_data);
            }
            else
            {


                while (current != null)
                {
                    if (count == (index - 1))
                    {
                        Node new_node = new Node(new_data);
                        new_node.next = current.next;
                        current.next = new_node;

                    }
                    count++;
                    current = current.next;
                }
            }


        }

        public void delete()
        {
            if (getCount(head) == 0)
            {
                throw new InvalidOperationException();
            }
            Node prev = head, current = head; // Initialize current  
            while (current.next != null)
            {
                prev = current;
                current = current.next;
            }
            prev.next = null;
        }




        public void reverseList()
        {
            Node prev = null, current = head, next = null;
            while (current != null)
            {
                next = current.next;
                current.next = prev;
                prev = current;
                current = next;
            }
            head = prev;
            printList();
        }

        public void deleteAtPosition(int position)
        {

            if (getCount(head) == 0)
            {
                throw new InvalidOperationException();
            }


            Node temp = head;


            if (position == 0)
            {


                head = temp.next;
                temp.next = null;

                return;
            }

            for (int i = 1; temp != null && i < position - 1; i++)
                temp = temp.next;

            if (temp == null || temp.next == null)
                return;


            Node node_next = temp.next.next;


            temp.next = node_next;
        }





        public void printList()
        {
            Node tnode = head;
            while (tnode != null)
            {
                Console.Write(tnode.data + " ");
                tnode = tnode.next;
            }
        }


        public void printMiddle(Node head)
        {
            Node prev = head;
            Node current = head;

            if (head != null)
            {
                while (current != null && current.next != null)
                {
                    current = current.next.next;
                    prev = prev.next;
                }
                Console.WriteLine("Middle Element  " + prev.data);
            }


        }






        public int getCount(Node head)
        {
            int count = 0;
            Node current = head;
            while (current != null)
            {
                count++;
                current = current.next;
            }
            return count;
        }


        public IEnumerable<int> GetList()
        {


            Node tnode = head;
            while (tnode != null)
            {
                yield return tnode.data; ;
                tnode = tnode.next;
            }


        }



    }
}