﻿using System;
using System.Collections.Generic;

namespace QueueImplementation
{
    class Queue
    {
        private int[] items;
        private int front;
        private int rear;
        private int max;

        public Queue(int size)
        {
            if (size < 0)
            {
                throw new ArgumentOutOfRangeException();
            }
            items = new int[size];
            front = 0;
            rear = -1;
            max = size;
        }


        public void enqueue(int item)
        {
            if (rear == max - 1)
            {
                Console.WriteLine("Queue Overflow");
                return;
            }
            else
            {
                items[++rear] = item;
            }

            Console.WriteLine(item + "  enqueued to queue");
        }


        public void dequeue()
        {
            if (size() == 0)
            {
                throw new InvalidOperationException();
            }


            else
            {
                Console.WriteLine(items[front] + " dequeued from queue");
                int p = items[front++];

            }
        }


        public void printQueue()
        {
            if (front == rear + 1)
            {
                Console.WriteLine("Queue is Empty");
                return;
            }
            else
            {
                for (int i = front; i <= rear; i++)
                {
                    Console.WriteLine(items[i]);
                }
            }
        }

        public int size()
        {
            int count = 0;
            for (int i = front; i <= rear; i++)
            {
                count = count + 1;

            }
            return count;


        }

        public void contains(int data)
        {
            if (size() == 0)
            {
                throw new InvalidOperationException();
            }

            for (int i = front; i <= rear; i++)
            {
                if (items[i] == data)
                {
                    Console.WriteLine("element Found");
                    break;
                }
            }

            Console.WriteLine("items not found ");

        }

        public void peek()
        {
            Console.WriteLine("items at front " + items[front]);
        }
        public void reverse()
        {
            int i, j, temp;
            for (i = front, j = rear; i < j; i++, j--)
            {
                temp = items[i];
                items[i] = items[j];
                items[j] = temp;
            }
            printQueue();
        }

        public IEnumerable<int> GetQueue()
        {


            foreach (var items in items)
            {

                yield return items;
            }



        }

    }
}
