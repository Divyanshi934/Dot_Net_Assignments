/*Exercise 6
Write a trigger for the Product table to ensure the list price can never be raised more than 15 Percent in a single change. Modify the 
above trigger to execute its check code only if the ListPrice column is updated (Use AdventureWorks Database)*/
 
    CREATE TRIGGER[production].[triggers1]
     ON[production].[product]
     FOR update
     AS
     IF exists(SELECT * FROM inserted i join deleted d ON i.ProductID=d.ProductID WHERE i.ListPrice>(d.ListPrice*1.15))
     BEGIN
     RAISERROR ('Price increase may not be greater than 15 percent' , 16 ,1) 
     ROLLBACK TRANSACTION
     END
	 UPDATE Production.Product SET ListPrice = 203 WHERE ProductID = 516;
     GO
     SELECT * FROM Production.Product WHERE ProductID = 516 ;
     GO
	 
    
/*Exercise 1:
The exercise requires SQL Server AdventureWorks OLTP database which can be found at Codeplex. Download and attach a copy of the 
database to your server instance. Take some time to appreciate the entire schema of the database, and functions and stored 
procedures (refer AdventureWorks 2008 OLTP Schema.pdf). Using the AdventureWorks database, perform the following queries.*/

--1. Display the number of records in the [SalesPerson] table. (Schema(s) involved: Sales)

     SELECT count(*)FROM Sales.SalesPerson

--2. Select both the FirstName and LastName of records from the Person table where the FirstName begins with the letter �B�. 
--  (Schema(s) involved: Person)
     
	 SELECT FirstName,LastName FROM Person.Person WHERE FirstName like 'b%'

--3. Select a list of FirstName and LastName for employees where Title is one of Design Engineer, Tool Designer or Marketing 
--   Assistant. (Schema(s) involved: HumanResources, Person)

    SELECT Person.Person.FirstName, Person.Person.LastName, HumanResources.Employee.JobTitle FROM Person.Person INNER JOIN
    HumanResources.Employee ON Person.Person.BusinessEntityID = HumanResources.Employee.BusinessEntityID
    WHERE HumanResources.Employee.JobTitle IN ('Design Engineer','Tool Designer','Marketing Assistant');

--4. Display the Name and Color of the Product with the maximum weight. (Schema(s) involved: Production)   

     SELECT Name,Color,Weight FROM Production.Product WHERE Weight is not null and Color is not null;


--5. Display Description and MaxQty fields from the SpecialOffer table. Some of the MaxQty values are NULL, in this case display 
--   the value 0.00 instead. (Schema(s) involved: Sales)

     SELECT DESCRIPTION ,ISNULL(MaxQty,0.00) AS 'MaxQty' FROM Sales.SpecialOffer;

--6. Display the overall Average of the [CurrencyRate].[AverageRate] values for the exchange rate �USD� to �GBP� for the year 2005 
--i.e. FromCurrencyCode = �USD� and ToCurrencyCode = �GBP�. Note: The field [CurrencyRate].[AverageRate] is defined as 
--'Average exchange rate for the day.' (Schema(s) involved: Sales)

     SELECT CurrencyRateDate,FromCurrencyCode,ToCurrencyCode,AverageRate FROM Sales.CurrencyRate
     WHERE DATEPART(YEAR,CurrencyRateDate)=2005 and ToCurrencyCode='GBP';


--7. Display the FirstName and LastName of records from the Person table where FirstName contains the letters �ss�. Display an 
--   additional column with sequential numbers for each row returned beginning at integer 1. (Schema(s) involved: Person)

     SELECT ROW_NUMBER() OVER (ORDER BY FirstName ASC) AS RowNumber,FirstName,LastName FROM Person.Person
     WHERE firstname like '%ss%';

--8.Sales people receive various commission rates that belong to 1 of 4 bands. (Schema(s) involved: Sales)

     SELECT BusinessEntityID AS SalesPersonID, 'Commision Band' = case
     WHEN CommissionPct = 0 THEN 'Band 0'
     WHEN CommissionPct BETWEEN 0 and 0.01 THEN 'Band 1' 
     WHEN CommissionPct BETWEEN 0.01 and 0.015 THEN 'Band 2'
     WHEN CommissionPct > 0.015 THEN 'Band 3'
     END
     FROM Sales.SalesPerson;

--9. Display the managerial hierarchy from Ruth Ellerbrock (person type � EM) up to CEO Ken Sanchez. Hint: use  [uspGetEmployeeManagers] (Schema(s) involved: [Person], [HumanResources]) 


     DECLARE @BId int
     SELECT @BId = p.BusinessEntityID FROM Person.Person p
     inner join HumanResources.Employee e
     ON p.BusinessEntityID = e.BusinessEntityID
     WHERE p.FirstName = 'Ruth' and PersonType = 'EM';
     EXECUTE dbo.uspGetEmployeeManagers @BId;

--10. Display the ProductId of the product with the largest stock level. 
    
	  select ProductID,Quantity from Production.ProductInventory order by Quantity desc;


/*Exercise 2:
Write separate queries using a join, a subquery, a CTE, and then an EXISTS to list all AdventureWorks customers who have not placed 
an order.*/
-- Using join

	  SELECT * FROM Sales.Customer c LEFT OUTER JOIN Sales.SalesOrderHeader s ON c.CustomerID = s.CustomerID
      WHERE s.SalesOrderID IS NULL

-- Using Subquery

      SELECT * FROM Sales.Customer c
      WHERE c.CustomerID NOT in( SELECT s.CustomerID FROM Sales.SalesOrderHeader s WHERE s.SalesOrderID IS NULL );
 
 -- Using CTE

      WITH cte AS (SELECT c.CustomerID AS T1_customer_id,s.CustomerID AS T2_customer_id
      FROM Sales.Customer AS c LEFT JOIN Sales.SalesOrderHeader AS s ON c.CustomerID = s.CustomerID)
      SELECT T1_customer_id AS 'Customer Id' FROM cte
      WHERE T2_customer_id is null;

 -- Using Exists

      SELECT * FROM Sales.Customer c WHERE NOT EXISTS( SELECT * FROM Sales.SalesOrderHeader s 
      WHERE s.SalesOrderID IS NULL AND c.CustomerID = s.CustomerID);

/*Exercise 3:
Show the most recent five orders that were purchased from account numbers that have spent more than $70,000 with 
AdventureWorks.*/

	  WITH cte_GetAccountNumber AS
      (
         SELECT AccountNumber, SUM(TotalDue) AS TotalDue
         FROM Sales.SalesOrderHeader
         GROUP BY AccountNumber
         HAVING SUM(TotalDue)>70000
      )

     SELECT TOP(5) * FROM Sales.SalesOrderHeader
     WHERE AccountNumber
     IN(SELECT AccountNumber FROM cte_GetAccountNumber)
     ORDER BY OrderDate DESC;


/* Exercise 4 :
Create a function that takes as inputs a SalesOrderID, a Currency Code, and a date, and returns a table of all the SalesOrderDetail rows 
for that Sales Order including Quantity, ProductID, UnitPrice, and the unit price converted to the target currency based on the end of 
day rate for the date provided. Exchange rates can be found in the Sales.CurrencyRate table. (Use AdventureWorks)*/
  
     USE AdventureWorks2008R2
     GO
     CREATE FUNCTION SalesOrdersDetail(@SalesOrderId int, @CurrencyCode nchar(3),@RateDate date)
     RETURNS TABLE
     AS
     RETURN 
     SELECT OrderQty,ProductID,UnitPrice,UnitPrice*cr.EndOfDayRate AS 'TotalPrice'
     FROM Sales.SalesOrderDetail, Sales.CurrencyRate AS cr
     WHERE SalesOrderID = @SalesOrderId and cr.ToCurrencyCode = @CurrencyCode and CurrencyRateDate = @RateDate;
     GO

/*Exercise 5:
 Write a Procedure supplying name information from the Person.Person table and accepting a filter for the first name. Alter the above 
Store Procedure to supply Default Values if user does not enter any value. ( Use AdventureWorks)*/

    create procedure person.udf_NameInformations1
     @Name varchar(50)
     as
     select FirstName,MiddleName,LastName
     from Person.Person
     where FirstName=@Name; 

  